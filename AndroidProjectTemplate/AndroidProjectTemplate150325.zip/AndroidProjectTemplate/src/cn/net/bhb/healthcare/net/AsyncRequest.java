package cn.net.bhb.healthcare.net;

import cn.net.bhb.healthcare.bean.Captcha;
import android.content.Context;
import android.os.AsyncTask;
import cn.net.bhb.healthcare.utils.ExecutorManager;

/**
 * 所有异步请求
 * @author Lynch
 */
public class AsyncRequest {

	public static void sendCode(final Context context, final String mobile, final int deviceId, final String nickname, final String validcodetype,
			final NetCallBack<ResponseResult> callback) {
		
		new AsyncTask<Void, Void, ResponseResult>() {
			@Override
			protected ResponseResult doInBackground(Void... params) {
				ResponseResult responseResult = ResponseResult.getResponseResultFromPost(ConnPackParam.sendVerifycode4RegisterByPhone("13512345678"));
				return responseResult;
			}

			@Override
			protected void onPostExecute(ResponseResult result) {
				super.onPostExecute(result);
				if (result.isSuccess) {
					Captcha captcha = ConnUnPackParam.getCaptcha(result.data);
					callback.onSuccess(result);
				} else {
					callback.onFail(result);
				}
			}
		}.executeOnExecutor(ExecutorManager.getLongPool());
	}
}
