package cn.net.bhb.healthcare.ui.base;

import java.util.List;

import android.widget.BaseAdapter;

public abstract class AdapterBase<T> extends BaseAdapter {
	
	protected ActBase mActBase;
	protected List<T> mDatas;

	public AdapterBase(ActBase activity, List<T> mDatas) {
		this.mActBase = activity;
		this.mDatas = mDatas;
	}

	@Override
	public int getCount() {
		return mDatas.size();
	}

	@Override
	public T getItem(int position) {
		return mDatas.get(position);
	}

	@Override
	public long getItemId(int position) {
		return position;
	}
}