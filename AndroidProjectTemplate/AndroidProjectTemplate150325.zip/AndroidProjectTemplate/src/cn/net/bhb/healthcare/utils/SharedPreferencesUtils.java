package cn.net.bhb.healthcare.utils;

import android.content.SharedPreferences;

/**
 * SharedPreferences工具类
 * @author Lynch
 */
public class SharedPreferencesUtils {

	/**
	 * 将键值对存入名为sp的SharedPreferences中
	 * @param sp SharedPreferences对象
	 * @param key 键
	 * @param value 值
	 */
	public static void putString(SharedPreferences sp, String key, String value) {
		sp.edit().putString(key, value).commit();
	}

	/**
	 * 从名为sp的SharedPreferences中获取键为key的对应的值，若没有则返回默认值defValue
	 * @param sp SharedPreferences对象
	 * @param key 键
	 * @param defValue 默认值
	 * @return
	 */
	public static String getString(SharedPreferences sp, String key, String defValue) {
		return sp.getString(key, defValue);
	}

	/**
	 * 将键值对存入名为sp的SharedPreferences中
	 * @param sp SharedPreferences对象
	 * @param key 键
	 * @param value 值
	 */
	public static void putBoolean(SharedPreferences sp, String key, boolean value) {
		sp.edit().putBoolean(key, value).commit();
	}

	/**
	 * 从名为sp的SharedPreferences中获取键为key的对应的值，若没有则返回默认值defValue
	 * @param sp SharedPreferences对象
	 * @param key 键
	 * @param defValue 默认值
	 * @return
	 */
	public static boolean getBoolean(SharedPreferences sp, String key, boolean defValue) {
		return sp.getBoolean(key, defValue);
	}

	/**
	 * 将键值对存入名为sp的SharedPreferences中
	 * @param sp SharedPreferences对象
	 * @param key 键
	 * @param value 值
	 */
	public static void putInt(SharedPreferences sp, String key, int value) {
		sp.edit().putInt(key, value).commit();
	}

	/**
	 * 从名为sp的SharedPreferences中获取键为key的对应的值，若没有则返回默认值defValue
	 * @param sp SharedPreferences对象
	 * @param key 键
	 * @param defValue 默认值
	 * @return
	 */
	public static int getInt(SharedPreferences sp, String key, int defValue) {
		return sp.getInt(key, defValue);
	}
}
