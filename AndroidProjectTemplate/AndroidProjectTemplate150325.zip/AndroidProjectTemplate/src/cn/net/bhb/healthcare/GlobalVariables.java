package cn.net.bhb.healthcare;

import android.content.SharedPreferences;

/**
 * 全局变量
 * @author Lynch
 */
public class GlobalVariables {

	/**
	 * 是否处于debug模式
	 */
	public static boolean debugMode = true;
	
	/**
	 * 编码
	 */
	public static final String Encoding = "UTF-8";

	/**
	 * 默认SharedPreferences数据Key
	 */
	public static final String SharedPreferencesKey = "spBaseData";
	
	//----------------------------------------避免在业务层传递Context------------------------------
	
	/**
	 * 数据目录，在Application中进行初始化
	 */
	public static String dataDir = "";
	
	/**
	 * 缓存目录，在Application中进行初始化
	 */
	public static String cacheDir = "";
	
	/**
	 * 默认SharedPreferences，在Application中进行初始化
	 */
	public static SharedPreferences spBaseData;
	
	/**
	 * 屏幕的宽度
	 */
	public static int WIN_WIDTH = 0;
	
	//-------------------------------------------业务相关------------------------------
	/**	
	 * 登录标记
	 */
	public static boolean IS_LOGIN = false;
}
