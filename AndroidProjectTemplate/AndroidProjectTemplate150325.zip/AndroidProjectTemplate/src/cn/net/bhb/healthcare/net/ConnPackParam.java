package cn.net.bhb.healthcare.net;

import java.util.HashMap;
import java.util.Map;

/**
 * 包装请求参数类
 * @author Lynch
 */
public class ConnPackParam {

	/**
	 * 手机注册-获取验证码
	 * @param phone
	 * @return
	 */
	public static Map<String, String> sendVerifycode4RegisterByPhone(String phone) {
		Map<String, String> params = new HashMap<String, String>();
		params.put("sys:cmd", "SendVerifycode4RegisterByPhone");
		params.put("op:phone", phone);
		return params;
	}
	
	/**
	 * 找回密码-获取验证码
	 * @param phone
	 * @return
	 */
	public static Map<String, String> sendVerifycode4ForgottenPassword(String phone) {
		Map<String, String> params = new HashMap<String, String>();
		params.put("sys:cmd", "SendVerifycode4ForgottenPassword");
		params.put("op:phone", phone);
		return params;
	}
}
