package cn.net.bhb.healthcare.utils;

import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.graphics.drawable.Drawable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import cn.net.bhb.healthcare.R;

/**
 * 警告对话框帮助类
 * @author Lynch
 */
public class AlertDialogUtils {
	
	public static AlertDialog getDialog(Context context, OnClickListener onClick, boolean cancelable) {
		View view = LayoutInflater.from(context).inflate(R.layout.layout_alert_dialog, null);
		
		View btnCancel = view.findViewById(R.id.btnCancel);
		View btnOk = view.findViewById(R.id.btnOk);
		btnCancel.setOnClickListener(onClick);
		btnOk.setOnClickListener(onClick);
		
		AlertDialog dialog = new AlertDialog.Builder(context)
				.setView(view)
				.setCancelable(cancelable)
				.create();

		return dialog;
	}

	public static void show(Context context, int titleId, int messageId,
			int leftBtnTextId,
			DialogInterface.OnClickListener leftClickListener,
			boolean cancelable) {
		show(context, titleId, messageId, leftBtnTextId, leftClickListener, -1,
				 cancelable);
	}

	public static void show(Context context, int titleId, int messageId,
			int leftBtnTextId,
			DialogInterface.OnClickListener leftClickListener,
			int rightBtnTextId,
			boolean cancelable) {
		show(context, null, titleId, messageId, leftBtnTextId,
				leftClickListener, rightBtnTextId,
				cancelable);
	}

	public static void show(Context context, String titleId, String messageId,
			String leftBtnTextId,
			DialogInterface.OnClickListener leftClickListener,
			String rightBtnTextId,
			boolean cancelable) {
		show(context, null, titleId, messageId, leftBtnTextId,
				leftClickListener, rightBtnTextId,
				cancelable);
	}

	public static void show(Context context, Drawable icon, int titleId,
			int messageId, int leftBtnTextId,
			DialogInterface.OnClickListener leftClickListener,
			int rightBtnTextId,
			boolean cancelable) {
		new AlertDialog.Builder(context).setIcon(icon).setTitle(titleId)
				.setMessage(messageId)
				.setPositiveButton(leftBtnTextId, leftClickListener)
				.setNegativeButton(rightBtnTextId, leftClickListener)
				.setCancelable(cancelable).create().show();
	}

	public static void show(Context context, Drawable icon, String titleId,
			String messageId, String leftBtnTextId,
			DialogInterface.OnClickListener leftClickListener,
			String rightBtnTextId,
			boolean cancelable) {
		new AlertDialog.Builder(context).setIcon(icon).setTitle(titleId)
				.setMessage(messageId)
				.setPositiveButton(leftBtnTextId, leftClickListener)
				.setNegativeButton(rightBtnTextId, leftClickListener)
				.setCancelable(cancelable).create().show();
	}
}
