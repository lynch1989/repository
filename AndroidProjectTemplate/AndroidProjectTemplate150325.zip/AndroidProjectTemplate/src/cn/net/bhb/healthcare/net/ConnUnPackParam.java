package cn.net.bhb.healthcare.net;

import android.text.TextUtils;
import cn.net.bhb.healthcare.bean.Captcha;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

/**
 * 拆包返回结果类 包括http返回的通用结果与个性化结果解析
 * @author Lynch
 */
public class ConnUnPackParam {

	/**
	 * 获取验证码
	 * @param json
	 * @return
	 */
	public static Captcha getCaptcha(String json) {
		Captcha captcha = null;
		if(!TextUtils.isEmpty(json)){
			captcha = new Gson().fromJson(json, new TypeToken<Captcha>(){}.getType());
		}
		return captcha;
	}
}
