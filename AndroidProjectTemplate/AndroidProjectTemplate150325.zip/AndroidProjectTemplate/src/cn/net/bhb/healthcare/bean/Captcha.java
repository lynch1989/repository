package cn.net.bhb.healthcare.bean;

import com.google.gson.annotations.SerializedName;

/**
 * 验证码
 * @author Lynch
 */
public class Captcha {

	@SerializedName("Code")
	public String code;
	@SerializedName("TimeoutMinute")
	public int timeoutMinute;
	
	public String getCode() {
		return code;
	}

	public void setCode(String code) {
		this.code = code;
	}

	public int getTimeoutMinute() {
		return timeoutMinute;
	}

	public void setTimeoutMinute(int timeoutMinute) {
		this.timeoutMinute = timeoutMinute;
	}

	@Override
	public String toString() {
		return "Captcha [code=" + code + ", timeoutMinute=" + timeoutMinute
				+ "]";
	}
}
