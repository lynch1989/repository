package cn.net.bhb.healthcare.utils;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;

import android.content.Context;
import android.os.Environment;
import android.util.Log;

/**
 * 统一管理 应用程序打印的log
 * @author Lynch
 */
public class LogUtils {
	
	/** 程序运行期间产生的文件，缓存根目录 */
	public static final String ROOT_DIR_PATH = "/HealthCare";
	/** 日志文件保存目录 */
	public static final String LOG_DIR_PATH = ROOT_DIR_PATH + "/logs";
	/** 当前log的状态 */
	public static boolean isOpen = false;
	/** log的路径 */
	public static final String LOG_PATH = LOG_DIR_PATH;

	/**
	 * 打开log
	 */
	public static void openLog() {
		if (!isOpen) {
			isOpen = true;
		}
	}

	/**
	 * 关闭log
	 */
	public static void closeLog() {
		if (isOpen) {
			isOpen = false;
		}
	}

	/**
	 * 错误信息
	 * 
	 * @param object
	 *            当前类对象
	 * @param msg
	 *            错误信息
	 */
	public static final void e(Class<?> object, String msg) {
		if (isOpen)
			Log.e(getTag(object, ""), msg);
	}

	public static final void e(Class<?> object, String tag, String msg) {
		if (isOpen)
			Log.e(getTag(object, tag), msg);
	}

	/**
	 * 警告信息
	 * 
	 * @param object
	 *            当前类对象
	 * @param msg
	 *            错误信息
	 */
	public static final void w(Class<?> object, String msg) {
		if (isOpen) {
			Log.w(getTag(object, ""), msg);
		}
	}

	public static final void w(Class<?> object, String tag, String msg) {
		if (isOpen) {
			Log.w(getTag(object, tag), msg);
		}
	}

	/**
	 * 正常信息
	 * 
	 * @param object
	 *            当前类对象
	 * @param msg
	 *            错误信息
	 */
	public static final void i(Class<?> object, String msg) {
		if (isOpen) {
			Log.i(getTag(object, ""), msg);
		}
	}

	public static final void i(Class<?> object, String tag, String msg) {
		if (isOpen) {
			Log.i(getTag(object, tag), msg);
		}
	}

	/**
	 * 调试信息
	 * 
	 * @param object
	 *            当前类对象
	 * @param msg
	 *            错误信息
	 */
	public static final void d(Class<?> object, String msg) {
		if (isOpen) {
			Log.d(getTag(object, ""), msg);
		}
	}

	public static final void d(Class<?> object, String tag, String msg) {
		if (isOpen) {
			Log.d(getTag(object, tag), msg);
		}
	}

	/**
	 * 正常信息
	 * 
	 * @param object
	 *            当前类对象
	 * @param msg
	 *            错误信息
	 */
	public static final void v(Class<?> object, String msg) {
		if (isOpen) {
			Log.v(getTag(object, ""), msg);
		}
	}

	public static final void v(Class<?> object, String tag, String msg) {
		if (isOpen) {
			Log.v(getTag(object, tag), msg);
		}
	}

	private static String getTag(Class<?> object, String tag) {
		return object.getSimpleName() + "_" + tag;
	}

	/**
	 * 将log写入文件
	 * 
	 * @param msg
	 * @param filename
	 * @param append
	 */
	public static void f(Context context, String msg, String filename, boolean append) {
		writeToFile(context, msg, filename, append);
	}

	public static void f(Context context, String msg, String filename) {
		writeToFile(context, msg, filename, false);
	}

	public static void f(Context context, String msg) {
		writeToFile(context, msg, "app.log", true);
	}

	public static void writeToFile(Context context, String msg, String filename, boolean append) {
		try {
			BufferedWriter bos = new BufferedWriter(new FileWriter(getStorePath(context) + "/" + filename, append));
			bos.write(msg + "\n");
			bos.flush();
			bos.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	/**
	 * 得到log文件的存放路径
	 * 
	 * @param context
	 * @return log文件路径
	 */
	public static String getStorePath(Context context) {
		// 判断SdCard是否存在并且是可用的
		String dirPath = context.getFilesDir().getAbsolutePath();
		if (Environment.MEDIA_MOUNTED.equals(Environment.getExternalStorageState())) {
			if (Environment.getExternalStorageDirectory().canWrite()) {
				dirPath = Environment.getExternalStorageDirectory().getPath() + LOG_PATH;
			}
		} else {
			dirPath = context.getFilesDir().getAbsolutePath() + LOG_PATH;
		}
		File file = new File(dirPath);
		if (!file.exists()) {
			file.mkdirs();
		}
		return file.getAbsolutePath();
	}
}
