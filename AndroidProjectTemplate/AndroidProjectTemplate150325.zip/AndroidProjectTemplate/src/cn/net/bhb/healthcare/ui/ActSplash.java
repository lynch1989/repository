package cn.net.bhb.healthcare.ui;

import java.util.Timer;
import java.util.TimerTask;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import cn.net.bhb.healthcare.R;

public class ActSplash extends Activity {

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.act_splash);
		
		delayStart();
	}

	/**
	 * 显示启动图片1.5秒 启动应用主页
	 */
	public void delayStart() {
		Timer timer = new Timer();
		TimerTask tt = new TimerTask() {
			@Override
			public void run() {
				skip();
			}
		};
		timer.schedule(tt, 1500);
	}
	
	private void skip() {
		Intent intent = new Intent(this, ActHome.class);
		startActivity(intent);
		finish();
	}
}
