package cn.net.bhb.healthcare.ui.base;

import android.app.Activity;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

public abstract class FragBase extends Fragment{
	
	private View mView;
	private int mLayoutId;
	protected LayoutInflater mInflater;
	protected Activity mActivity;
	
	protected FragBase(){
		this.mLayoutId = getLayoutId();
	}
	
	@Override
	public View onCreateView(LayoutInflater inflater, ViewGroup container,
			Bundle savedInstanceState) {
		this.mInflater = inflater;
		this.mActivity = getActivity();
		if(null == mView){
			mView = inflater.inflate(mLayoutId, container, false);
			initViews(mView);
			bindEvents();
			initDatas();
		}else {
			ViewGroup parent = (ViewGroup) mView.getParent();       
			if (parent != null) {            
				parent.removeView(mView);         
			}
		}
		return mView;
	}

	protected abstract int getLayoutId();
	
	protected abstract void initViews(View view);
	
	protected abstract void bindEvents();
	
	protected abstract void initDatas();
}
