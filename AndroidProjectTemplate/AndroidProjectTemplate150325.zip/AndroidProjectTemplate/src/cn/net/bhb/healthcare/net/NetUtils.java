package cn.net.bhb.healthcare.net;

import android.content.ContentResolver;
import android.content.Context;
import android.database.Cursor;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.net.Uri;
import android.util.Log;

/**
 * 网络工具类
 * @author Lynch
 */
public class NetUtils {
	
	private static final String TAG = "NetUtils";
	//4.0模拟器屏蔽掉该权限(google手机)——没有权限
	private static Uri PREFERRED_APN_URI = Uri.parse("content://telephony/carriers/preferapn");

	/**
	 * 检查网络
	 * @return
	 */
	public static boolean checkNet(Context context)
	{
		// 操作步骤
		// ①判断WLAN（wi-fi）联网
		// ②手机APN接入点（基站）
		// 如果没有联网——提示用户
		// 如果是手机APN接入点（基站）
		// 判断WAP还是NET
		
		//判断WLAN（wi-fi）联网
		boolean isWIFI = isWIFIConnectivity(context);
		Log.i(TAG, "wifi:" + isWIFI);
		
		//手机APN接入点（基站）
		boolean isMOBILE = isMOBILEConnectivity(context);
		Log.i(TAG, "isMOBILE:" + isMOBILE);
		
		if(!isWIFI && !isMOBILE)
		{
			return false;
		}
		
		//如果是手机APN接入点（基站）
		if(isMOBILE)
		{
			//判断WAP还是NET
			//读取APN的配置信息，如果发现“proxy”“port”有数据，需要设置代理
			readAPN(context);//
		}
		return true;
	}
	
	private static void readAPN(Context context) {
		ContentResolver resolver = context.getContentResolver();
		Cursor cursor = resolver.query(PREFERRED_APN_URI, null, null, null, null);//如果真机APN列表，获取到列表中被选中
		if(cursor!=null)
		{
			if(cursor.moveToFirst())
			{
				ConnConstants.PROXY = cursor.getString(cursor.getColumnIndex("proxy"));
				ConnConstants.PORT = cursor.getInt(cursor.getColumnIndex("port"));
			}
		}
	}
	
	/**
	 * 手机APN接入点（基站）
	 * @param context
	 * @return
	 */
	private static boolean isMOBILEConnectivity(Context context) {
		ConnectivityManager manager = (ConnectivityManager) context.getSystemService(Context.CONNECTIVITY_SERVICE);
		NetworkInfo networkInfo = manager.getNetworkInfo(ConnectivityManager.TYPE_MOBILE);
		if (networkInfo != null)
		{
			return networkInfo.isConnected();
		}
		return false;
	}
	
	/**
	 * 判断WLAN（wi-fi）联网
	 * @param context
	 * @return
	 */
	public static boolean isWIFIConnectivity(Context context) {
		// ConnectivityManager——系统服务
		ConnectivityManager manager =(ConnectivityManager) context.getSystemService(Context.CONNECTIVITY_SERVICE);
		NetworkInfo networkInfo = manager.getNetworkInfo(ConnectivityManager.TYPE_WIFI);
		if (networkInfo !=null)
		{
			return networkInfo.isConnected();
		}
		return false;
	}
	
	/**
	 * 判断是否允许下载图片
	 * @param context
	 * @return
	 */
//	public static boolean isAllowedToDownloadImage(Context context){
//		boolean isAllowed = false;
//		boolean onlyOnWifiNetworkToDownloadImage = GlobalParams.spBaseData.getBoolean(GlobalParams.ONLY_WIFI_NETWORK_TO_DOWNLOAD_IMAGE_KEY, false);
//		if((onlyOnWifiNetworkToDownloadImage && NetUtils.isWIFIConnectivity(context)) || !onlyOnWifiNetworkToDownloadImage) {
//			isAllowed = true;
//		}
//		return isAllowed;
//	}
}
