package cn.net.bhb.healthcare.net;

public interface NetCallBack<T> {

	public void onSuccess(T t);
	
	public void onFail(T t);
}
