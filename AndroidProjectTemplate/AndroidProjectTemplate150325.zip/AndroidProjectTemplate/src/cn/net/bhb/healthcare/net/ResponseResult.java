package cn.net.bhb.healthcare.net;

import java.io.File;
import java.util.Map;

import org.json.JSONException;
import org.json.JSONObject;

import com.google.gson.annotations.SerializedName;

public class ResponseResult {

	@SerializedName("IsSccuess")
	public boolean isSuccess;
	@SerializedName("ErrorCode")
	public int errorCode;
	@SerializedName("Message")
	public String message;
	@SerializedName("Data")
	public String data;
	@SerializedName("ActionVersion")
	public String actionVersion;
	
	@Override
	public String toString() {
		return "ResponseResult [isSuccess=" + isSuccess + ", errorCode="
				+ errorCode + ", message=" + message
				+ ",data=" + data
				+ ", actionVersion=" + actionVersion + "]";
	}
	
	/**
	 * 解析响应结果
	 * @param resultJson
	 * @return
	 */
	public static ResponseResult parseResponseResult(String resultJson) {
		ResponseResult responseResult = new ResponseResult();
		try {
			JSONObject jsonObject = new JSONObject(resultJson);
			responseResult.isSuccess = jsonObject.getBoolean("IsSccuess");
			responseResult.errorCode = jsonObject.getInt("ErrorCode");
			responseResult.message = jsonObject.getString("Message");
			responseResult.data = jsonObject.getString("Data");
			responseResult.actionVersion = jsonObject.getString("ActionVersion");
		} catch (JSONException e) {
			e.printStackTrace();
			//TODO
			responseResult.isSuccess = false;
			responseResult.errorCode = 1001;
			responseResult.message = "无效响应结果";
		}
		return responseResult;
	}
	
	/**
	 * 获取POST响应结果
	 * @param params
	 * @return
	 */
	public static ResponseResult getResponseResultFromPost(Map<String, String> params){
		ResponseResult responseResult = null;
		try {
			String resultJson = new ConnHttpRequest().sendPost(ConnConstants.requestUrl, params);
			responseResult = ResponseResult.parseResponseResult(resultJson);
		} catch (ErrorException e) {
			e.printStackTrace();
			responseResult = new ResponseResult();
			responseResult.isSuccess = false;
			responseResult.errorCode = e.getErrorCode();
			responseResult.message = e.getErrorMessage();
 		}
		return responseResult;
	}
	
	/**
	 * 获取GET响应结果
	 * @param params
	 * @return
	 */
	public static ResponseResult getResponseResultFromGet(Map<String, String> params){
		ResponseResult responseResult = null;
		try {
			String resultJson = new ConnHttpRequest().sendGet(ConnConstants.requestUrl, params);
			responseResult = ResponseResult.parseResponseResult(resultJson);
		} catch (ErrorException e) {
			e.printStackTrace();
			responseResult = new ResponseResult();
			responseResult.isSuccess = false;
			responseResult.errorCode = e.getErrorCode();
			responseResult.message = e.getErrorMessage();
		}
		return responseResult;
	}
	
	/**
	 * 获取Upload响应结果
	 * @param params
	 * @return
	 */
	public static ResponseResult getResponseResultFromUpload(Map<String, String> params, String fileKey, File fileValue){
		ResponseResult responseResult = null;
		String resultJson = new ConnHttpRequest().uploadSubmit(ConnConstants.requestUrl, params, fileKey, fileValue);
		responseResult = ResponseResult.parseResponseResult(resultJson);
		return responseResult;
	}
}
