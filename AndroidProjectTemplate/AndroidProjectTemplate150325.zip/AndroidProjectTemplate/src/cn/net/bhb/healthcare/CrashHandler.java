package cn.net.bhb.healthcare;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.PrintWriter;
import java.io.RandomAccessFile;
import java.io.StringWriter;
import java.io.Writer;
import java.lang.Thread.UncaughtExceptionHandler;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Properties;

import android.annotation.SuppressLint;
import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Environment;
import android.os.Looper;
import android.text.TextUtils;
import android.util.Log;
import android.widget.Toast;
import cn.net.bhb.healthcare.ui.ActSplash;

public class CrashHandler implements UncaughtExceptionHandler {

	private static final String TAG = CrashHandler.class.getName();
	/**
	 * 休息时间
	 */
	private static final long SLEEP_TIME = 2000;
	/** 写文件的锁对象 */
	private static final Object mLogLock = new Object();
	public static String APP_NAME;
    public static int APP_VERSION_CODE;
    public static String APP_VERSION_NAME;
    public static String APP_PACKAGE;
    public static File EXT_STORAGE;
    public static File APP_STORAGE;
    public static Properties BUILD_PROPS;
	
	/**
	 * 系统默认的UncaughtException处理类
	 */
	private Thread.UncaughtExceptionHandler mDefaultHandler;
    private Context mContext;
    
    private static CrashHandler instance = new CrashHandler();
	private CrashHandler() {
	}
	public static CrashHandler getInstance() {
		return instance;
	}

	public void init(Context context) {
		this.mContext = context;
		// 获取系统默认的UncaughtException处理器
		mDefaultHandler = Thread.getDefaultUncaughtExceptionHandler();
		// 设置该CrashHandler为程序的默认处理器
		Thread.setDefaultUncaughtExceptionHandler(this);
		
		final PackageManager pm = mContext.getPackageManager();
        try {
            final PackageInfo pi = pm.getPackageInfo(mContext.getPackageName(), 0);
            APP_NAME = mContext.getString(pi.applicationInfo.labelRes);
            APP_VERSION_CODE = pi.versionCode;
            APP_VERSION_NAME = !TextUtils.isEmpty(pi.versionName) ? pi.versionName : "TEST";
            APP_PACKAGE = pi.packageName;
            EXT_STORAGE = Environment.getExternalStorageDirectory();
            // System
            BUILD_PROPS = new Properties();
            try {
                BUILD_PROPS.load(new FileInputStream("/system/build.prop"));
            } catch (final Throwable th) {
            }
        } catch (Exception ex) {
            ex.printStackTrace();
        }
	}

	@Override
	public void uncaughtException(Thread thread, Throwable ex) {
		if(!handleException(ex) && mDefaultHandler != null){
            //如果用户没有处理则让系统默认的异常处理器来处理
            mDefaultHandler.uncaughtException(thread, ex);
        }else{
            try{
                Thread.sleep(SLEEP_TIME);
            }catch (InterruptedException e){
                Log.e(TAG, "error : ", e);
            }
            //1秒钟后重启应用
            Intent intent = new Intent(mContext, ActSplash.class);
			PendingIntent restartIntent = PendingIntent.getActivity(mContext, 0, intent, Intent.FLAG_ACTIVITY_NEW_TASK);
			AlarmManager mgr = (AlarmManager) mContext.getSystemService(Context.ALARM_SERVICE);
			mgr.set(AlarmManager.RTC, System.currentTimeMillis() + 1000, restartIntent);
			//退出程序
            HealthCareApplication.getInstance().exitApp();
        }
	}
	
	/**  
     * 自定义错误处理,收集错误信息 发送错误报告等操作均在此完成.  
     * @param ex  
     * @return 如果处理了该异常信息返回true;否则返回false.  
     */    
    private boolean handleException(Throwable ex) {
		if (ex == null) {
			return false;
		}
		ex.printStackTrace();
		
        //使用Toast来显示异常信息    
        new Thread(){    
            @Override    
            public void run() {    
				Looper.prepare();
				Toast.makeText(mContext, "很抱歉，程序出现异常，即将退出！", Toast.LENGTH_SHORT).show();
				Looper.loop();
            }   
        }.start();
        
        final String crashMessage = createCrashMessage(ex);
		Log.e(TAG, crashMessage);
        
        final String filename = APP_PACKAGE + "." + APP_VERSION_NAME + "." + getCurrentTime() + ".stacktrace";
		String savePath;
		if (isSDCardAvailable()) {
			savePath = mContext.getExternalCacheDir().getAbsolutePath() + File.separator;
		} else {
			savePath = mContext.getCacheDir().getAbsolutePath() + File.separator;
		}
		savePath += "crash" + File.separator;
		String logPath = savePath + filename;
		synchronized (mLogLock) {
			writeFile(crashMessage + "\r\n", logPath, true);
		}
		Log.e(TAG, "Stacktrace is written: " + filename);
        
        return true;    
    }    

	private String createCrashMessage(Throwable ex) {
		final Writer result = new StringWriter();
        final PrintWriter printWriter = new PrintWriter(result);
        if(ex != null){
        	ex.printStackTrace(printWriter);
        }
        final String stacktrace = result.toString();
        printWriter.close();
		
		StringBuilder sBuilder = new StringBuilder();
		sBuilder.append("Application information:\n\n");
        sBuilder.append("This file was generated by the " + APP_PACKAGE + "." + APP_VERSION_NAME + "(" + APP_VERSION_CODE + ")\n");
        sBuilder.append("\nCurrent Time : " + getCurrentTime() + "\n\n");
        sBuilder.append("\nDevice information:\n\n");
        sBuilder.append("VERSION     : " + android.os.Build.VERSION.SDK_INT + "\n");
        sBuilder.append("BOARD       : " + Build.BOARD + "\n");
        sBuilder.append("BRAND       : " + Build.BRAND + "\n");
        sBuilder.append("CPU_ABI     : " + BUILD_PROPS.getProperty("ro.product.cpu.abi") + "\n");
        sBuilder.append("CPU_ABI2    : " + BUILD_PROPS.getProperty("ro.product.cpu.abi2") + "\n");
        sBuilder.append("DEVICE      : " + Build.DEVICE + "\n");
        sBuilder.append("DISPLAY     : " + Build.DISPLAY + "\n");
        sBuilder.append("FINGERPRINT : " + Build.FINGERPRINT + "\n");
        sBuilder.append("ID          : " + Build.ID + "\n");
        sBuilder.append("MANUFACTURER: " + BUILD_PROPS.getProperty("ro.product.manufacturer") + "\n");
        sBuilder.append("MODEL       : " + Build.MODEL + "\n");
        sBuilder.append("PRODUCT     : " + Build.PRODUCT + "\n");
        sBuilder.append("\nError Info:\n\n");
        sBuilder.append(stacktrace);
        
		return sBuilder.toString();
	}
	
	/**
	 * 判断SD卡是否挂载
	 * 
	 * @return
	 */
	public static boolean isSDCardAvailable() {
		if (Environment.MEDIA_MOUNTED.equals(Environment
				.getExternalStorageState())) {
			return true;
		} else {
			return false;
		}
	}
	
	/**
	 * 把字符串数据写入文件
	 * @param content 需要写入的字符串
	 * @param path 文件路径名称
	 * @param append 是否以添加的模式写入
	 * @return 是否写入成功
	 */
	public static boolean writeFile(byte[] content, String path, boolean append) {
		boolean res = false;
		File f = new File(path);
		RandomAccessFile raf = null;
		try {
			if (f.exists()) {
				if (!append) {
					f.delete();
					f.createNewFile();
				}
			} else {
				f.createNewFile();
			}
			if (f.canWrite()) {
				raf = new RandomAccessFile(f, "rw");
				raf.seek(raf.length());
				raf.write(content);
				res = true;
			}
		} catch (Exception e) {
			Log.e(TAG, "", e);
		} finally {
			if (raf != null) {
				try {
					raf.close();
				} catch (IOException e) {
					Log.e(TAG, e.fillInStackTrace().toString());
				}
			}
		}
		return res;
	}

	/**
	 * 把字符串数据写入文件
	 * @param content 需要写入的字符串
	 * @param path 文件路径名称
	 * @param append 是否以添加的模式写入
	 * @return 是否写入成功
	 */
	public static boolean writeFile(String content, String path, boolean append) {
		return writeFile(content.getBytes(), path, append);
	}
	
	@SuppressLint("SimpleDateFormat")
	public static String getCurrentTime() {
		SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		String dateString = formatter.format(new Date());
		return dateString;
	}
}
