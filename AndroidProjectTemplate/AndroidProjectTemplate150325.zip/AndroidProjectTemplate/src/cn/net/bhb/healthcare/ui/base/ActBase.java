package cn.net.bhb.healthcare.ui.base;

import android.app.Activity;
import android.content.Intent;
import android.content.pm.ActivityInfo;
import android.os.Bundle;
import android.support.v4.app.FragmentActivity;
import cn.net.bhb.healthcare.HealthCareApplication;
import cn.net.bhb.healthcare.R;

public abstract class ActBase extends FragmentActivity{
	
	protected Activity mActivity;
	/**
	 * 是否竖直切换界面标记
	 */
	private boolean isVerticalSwitch = false;

	@Override
	protected void onCreate(Bundle bundle) {
		super.onCreate(bundle);
		
		mActivity = ActBase.this;
		HealthCareApplication.getInstance().addActivity(mActivity);
		
		//设置屏幕固定竖直显示
		setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_PORTRAIT);
		
		initView();
		bindEvent();
		initData();
	}

	/**
	 * 初始化view
	 */
	protected abstract void initView();
	
	/**
	 * 绑定事件
	 */
	protected abstract void bindEvent();
	
	/**
	 * 初始化数据
	 */
	protected abstract void initData();
	
	/**
	 * 判断是否竖直切换界面
	 * @return
	 */
	public boolean isVerticalSwitch() {
		return isVerticalSwitch;
	}

	/**
	 * 设置是否竖直切换界面标记
	 * @param isVertical
	 */
	public void setVerticalSwitch(boolean isVerticalSwitch) {
		this.isVerticalSwitch = isVerticalSwitch;
	}

	/**
	 * 标题栏后退键点击事件
	 */
	protected void onBtnBackClick() {
	}
	
	/**
	 * 从右向左滑动进入新界面
	 * @param intent
	 */
	public void enterFromRightToLeft(Intent intent){
		mActivity.startActivity(intent);
		mActivity.overridePendingTransition(R.anim.enter_right_left, 0);
	}
	
	/**
	 * 从左向右滑动退出当前界面
	 */
	public void exitFromLeftToRight(){
//		mActivity.finish();
//		mActivity.overridePendingTransition(0, R.anim.exit_left_right);
		HealthCareApplication.getInstance().exitActivity(true, false);
	}
	
	/**
	 * 从下向上滑动进入新界面
	 * @param intent
	 */
	public void enterFromBottomToTop(Intent intent){
		mActivity.startActivity(intent);
		mActivity.overridePendingTransition(R.anim.enter_bottom_top, 0);
	}
	
	/**
	 * 从上向下滑动退出当前界面
	 */
	public void exitFromTopToBottom(){
//		mActivity.finish();
//		mActivity.overridePendingTransition(0, R.anim.exit_top_bottom);
		HealthCareApplication.getInstance().exitActivity(true, true);
	}
	
	/**
	 * 后退键点击事件
	 */
	@Override
	public void onBackPressed() {
		if(isVerticalSwitch()){
			exitFromTopToBottom();
		}else{
			exitFromLeftToRight();
		}
	}
}
