package cn.net.bhb.healthcare;

import java.io.File;
import java.util.Stack;

import cn.net.bhb.healthcare.utils.LogUtils;

import android.app.Activity;
import android.app.ActivityManager;
import android.app.Application;
import android.content.Context;
import android.os.Environment;

public class HealthCareApplication extends Application {
	
	/**
	 * 启动的Activity集合
	 */
	public static Stack<Activity> mActivityStack = new Stack<Activity>();
	/**
	 * 全局Context，原理是因为Application类是应用最先运行的，所以在我们的代码调用时，该值已经被赋值过了
	 */
	private static HealthCareApplication instance;
	
	public static HealthCareApplication getInstance(){
		return instance;
	}

	@Override
	public void onCreate() {
		super.onCreate();
		
		instance = this;
		
		// 初始化一些全局变量
        GlobalVariables.debugMode = true;
		LogUtils.isOpen = GlobalVariables.debugMode;
		GlobalVariables.dataDir = getApplicationContext().getFilesDir().getAbsolutePath() + File.separator;
		if (isSDCardAvailable()) {
			GlobalVariables.cacheDir = getApplicationContext().getExternalCacheDir().getAbsolutePath() + File.separator;
		} else {
			GlobalVariables.cacheDir = getApplicationContext().getCacheDir().getAbsolutePath() + File.separator;
		}
		GlobalVariables.spBaseData = getApplicationContext().getSharedPreferences(GlobalVariables.SharedPreferencesKey, MODE_PRIVATE);
		
		//TODO 初始化异常抓取Handler
//		CrashHandler.getInstance().init(getApplicationContext());
	}

	/**
	 * 判断SD卡是否挂载
	 * 
	 * @return
	 */
	public static boolean isSDCardAvailable() {
		if (Environment.MEDIA_MOUNTED.equals(Environment.getExternalStorageState())) {
			return true;
		} else {
			return false;
		}
	}
	
	/**
	 * 添加Activity到堆栈
	 */
	public synchronized void addActivity(Activity activity) {
		if (!mActivityStack.contains(activity)) {
			mActivityStack.add(activity);
		}
	}

	/**
	 * 获取当前Activity对象（堆栈中最后一个压入的）
	 */
	public Activity getCurrentActivity() {
		if (!mActivityStack.isEmpty()) {
			return mActivityStack.lastElement();
		}
		return null;
	}

	/**
	 * 返回到指定的Activity并且清除Stack中其位置之前（上）的所有Activity
	 */
	public Activity getSingleTaskActivity(Class<?> clz, boolean isAnimation, boolean isVerticalSwitch) {
		Activity destActivity = null;
		if (null != clz) {
			int position = 0;
			if (null != mActivityStack && mActivityStack.size() > 0) {
				for (int i = 0; i < mActivityStack.size(); i++) {
					if (mActivityStack.get(i).getClass().getName().contains(clz.getName())) {
						position = i;
					}
				}
				int num = mActivityStack.size() - position - 1;
				if (num > 0) {
					for (int i = 0; i < num; i++) {
						if (!mActivityStack.isEmpty()) {
							exitActivity(mActivityStack.pop(), isAnimation, isVerticalSwitch);
						}
					}
				}
				destActivity = mActivityStack.pop();
			}
		}
		return destActivity;
	}

	/**
	 * 结束当前Activity（堆栈中最后一个压入的）
	 */
	public void exitActivity(boolean isAnimation, boolean isVerticalSwitch) {
		if (!mActivityStack.isEmpty()) {
			Activity activity = mActivityStack.lastElement();
			exitActivity(activity, isAnimation, isVerticalSwitch);
		}
	}

	/**
	 * 结束指定类名的Activity
	 */
	public void exitActivity(Class<?> cls, boolean isAnimation, boolean isVerticalSwitch) {
		for (Activity activity : mActivityStack) {
			if (activity.getClass().equals(cls)) {
				exitActivity(activity, isAnimation, isVerticalSwitch);
			}
		}
	}
	
	/**
	 * 结束指定的Activity
	 */
	public synchronized void exitActivity(Activity activity, boolean isAnimation, boolean isVerticalSwitch) {
		if (activity != null) {
			mActivityStack.remove(activity);
			activity.finish();
			if(isVerticalSwitch){
				activity.overridePendingTransition(0, R.anim.exit_top_bottom);
			}else{
				activity.overridePendingTransition(0, R.anim.exit_left_right);
			}
			activity = null;
		}
	}

	/**
	 * 结束所有Activity
	 */
	public void exitAllActivity(boolean isAnimation, boolean isVerticalSwitch) {
		for (int i = 0, size = mActivityStack.size(); i < size; i++) {
			if (null != mActivityStack.get(i)) {
				exitActivity(mActivityStack.get(i), isAnimation, isVerticalSwitch);
			}
		}
		mActivityStack.clear();
	}

	/**
	 * 退出应用程序
	 */
	public void exitApp() {
		try {
			exitAllActivity(false, false);
			ActivityManager mActivityManager = (ActivityManager) getInstance().getSystemService(Context.ACTIVITY_SERVICE);
			mActivityManager.killBackgroundProcesses(getInstance().getPackageName());
			System.exit(0);
		} catch (Exception e) {
			e.printStackTrace();
			System.exit(0);
		}
	}
}
