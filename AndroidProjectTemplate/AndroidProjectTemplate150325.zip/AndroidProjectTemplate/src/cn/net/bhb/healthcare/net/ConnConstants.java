package cn.net.bhb.healthcare.net;


/**
 * 网络连接常量
 * @author Lynch
 */
public class ConnConstants {

	/**
	 * 请求地址
	 */
	public static final String requestUrl = "http://www.jizhigame.com/api/v1.1/action.ashx";
	
	/**
	 * 代理的IP
	 */
	public static String PROXY = "";
	
	/**
	 * 代理的端口
	 */
	public static int PORT = 0;
}
