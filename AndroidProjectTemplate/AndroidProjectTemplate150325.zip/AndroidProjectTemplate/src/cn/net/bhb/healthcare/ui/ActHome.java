package cn.net.bhb.healthcare.ui;

import android.view.View;
import cn.net.bhb.healthcare.R;
import cn.net.bhb.healthcare.ui.base.ActBase;
import cn.net.bhb.healthcare.utils.ToastUtils;
import cn.net.bhb.healthcare.view.TitleView;
import cn.net.bhb.healthcare.view.TitleView.OnRightButtonClickListener;

public class ActHome extends ActBase {

	private TitleView titleView;
	
	@Override
	protected void initView() {
		setContentView(R.layout.act_home);
		
		titleView = (TitleView) findViewById(R.id.titleView);
	}

	@Override
	protected void bindEvent() {
		//设置后退按钮
		titleView.setLeftBackImage(mActivity, false);
		
		titleView.setRightText("测试按钮1", new OnRightButtonClickListener() {
			@Override
			public void onClick(View v) {
				ToastUtils.showShortOnBackground(mActivity, "aaa");
			}
		});
	}

	@Override
	protected void initData() {
		titleView.setTitle(R.string.titleview_act_home_title);
	}
}
