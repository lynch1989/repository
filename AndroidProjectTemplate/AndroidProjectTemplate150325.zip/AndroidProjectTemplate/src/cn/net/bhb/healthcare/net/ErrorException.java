package cn.net.bhb.healthcare.net;

/**
 * 错误Exception
 * @author Lynch
 */
public class ErrorException extends Exception {

	private static final long serialVersionUID = 1L;
	/**
	 * 连接服务器失败，手机网络有问题
	 */
	public static final int Ex_Connection = 1;
	/**
	 * 服务器返回码错误，客户端传的参数有问题
	 */
	public static final int Ex_ResponseCode = 2;
	/**
	 * Json消息错误
	 */
	public static final int Ex_JsonCode = 3;
	/**
	 * 连接超时，遇到这种bug，试着重试一次
	 */
	public static final int Ex_TimeOut = 4;
	
	private int errorCode;
	private String errorMessage;
	
	public ErrorException(int errorCode,String errorMessage){
		super();
		this.errorCode=errorCode;
		this.errorMessage=errorMessage;
	}

	public int getErrorCode() {
		return errorCode;
	}

	public String getErrorMessage() {
		return errorMessage;
	}

	@Override
	public String toString() {
		return "ErrorServerException [errorCode=" + errorCode
				+ ", errorMessage=" + errorMessage + "]";
	}
}
