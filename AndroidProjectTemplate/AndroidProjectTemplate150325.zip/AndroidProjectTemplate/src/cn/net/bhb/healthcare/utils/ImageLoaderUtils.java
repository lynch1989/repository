package cn.net.bhb.healthcare.utils;

import java.util.Collections;
import java.util.LinkedList;
import java.util.List;

import android.content.Context;
import android.graphics.Bitmap;
import android.view.View;
import android.widget.ImageView;

import com.nostra13.universalimageloader.cache.disc.naming.Md5FileNameGenerator;
import com.nostra13.universalimageloader.core.DisplayImageOptions;
import com.nostra13.universalimageloader.core.ImageLoader;
import com.nostra13.universalimageloader.core.ImageLoaderConfiguration;
import com.nostra13.universalimageloader.core.assist.ImageScaleType;
import com.nostra13.universalimageloader.core.assist.QueueProcessingType;
import com.nostra13.universalimageloader.core.display.FadeInBitmapDisplayer;
import com.nostra13.universalimageloader.core.display.RoundedBitmapDisplayer;
import com.nostra13.universalimageloader.core.display.SimpleBitmapDisplayer;
import com.nostra13.universalimageloader.core.listener.SimpleImageLoadingListener;

/**
 * ImageLoader工具类
 * @author Lynch
 */
public class ImageLoaderUtils {
	
	private static ImageLoaderUtils mInstance = null;
	private ImageLoaderUtils() {
	}
	public static ImageLoaderUtils getInstance(Context context){
		if(mInstance == null){
			mInstance = new ImageLoaderUtils();
			initImageLoader(context);
		}
		return mInstance;
	}
	private DisplayImageOptions circleImageOption;
	private AnimateFirstDisplayListener displayListener ;
	
	/**
	 * 初始化ImageLoader
	 */
	private static void initImageLoader(Context context) {
		// This configuration tuning is custom. You can tune every option, you
		// may tune some of them,
		// or you can create default configuration by
		// ImageLoaderConfiguration.createDefault(this);
		// method.
		ImageLoaderConfiguration config = new ImageLoaderConfiguration.Builder(
				context).threadPriority(Thread.NORM_PRIORITY - 2)
				.denyCacheImageMultipleSizesInMemory()
				.diskCacheFileNameGenerator(new Md5FileNameGenerator())
				.tasksProcessingOrder(QueueProcessingType.LIFO)
				.writeDebugLogs() // Remove for release app
				.build();
		// Initialize ImageLoader with configuration.
		ImageLoader.getInstance().init(config);
	}
	
	/**
	 * 为ImageView设置图片
	 * @param viewId
	 * @param drawableId
	 * @return
	 */
	public void setImageByUrl(ImageView iv, String url, int loadingImage, int emptyImage, int failImage) {
//		ImageLoader.getInstance(3, Type.LIFO).loadImage(url, iv));
		DisplayImageOptions options = new DisplayImageOptions.Builder()
		.showImageOnLoading(loadingImage)
		.showImageForEmptyUri(emptyImage)
		.showImageOnFail(failImage)
		.cacheInMemory(true)
		.cacheOnDisk(true) 
		.imageScaleType(ImageScaleType.NONE)//不处理
		.considerExifParams(true)
		.displayer(new SimpleBitmapDisplayer())
		.build();
		ImageLoader.getInstance().displayImage(url, iv, options, new AnimateFirstDisplayListener());
	}
	
	/**
	 * 为圆角ImageView设置图片
	 * @param viewId
	 * @param drawableId
	 * @return
	 */
	public void setCircleImageByUrl(ImageView iv, String url, int loadingImage, int emptyImage, int failImage, int radius) {
		if (circleImageOption==null) {
			
			circleImageOption = new DisplayImageOptions.Builder()
			.showImageOnLoading(loadingImage)//设置图片在下载期间显示的图片
			.showImageForEmptyUri(emptyImage)//设置图片Uri为空或是错误的时候显示的图片
			.showImageOnFail(failImage)//设置图片加载/解码过程中错误时候显示的图片
			.cacheInMemory(true)//设置下载的图片是否缓存在内存中
			.cacheOnDisk(true)//设置下载的图片是否缓存在SD卡中
			.considerExifParams(true)//是否考虑JPEG图像EXIF参数（旋转，翻转）
			.imageScaleType(ImageScaleType.EXACTLY_STRETCHED)//设置图片以如何的编码方式显示//不处理
//	    .bitmapConfig(Bitmap.Config.RGB_565)//设置图片的解码类型
			//设置图片加入缓存前，对bitmap进行设置
			.resetViewBeforeLoading(true)//设置图片在下载前是否重置，复位  
			.displayer(new RoundedBitmapDisplayer(radius))//是否设置为圆角，弧度为多少  
			.build();//构建完成  
		}
		if (displayListener==null) {
			displayListener= new AnimateFirstDisplayListener();
		}
		ImageLoader.getInstance().displayImage(url, iv, circleImageOption, displayListener);
	}
	
	private static class AnimateFirstDisplayListener extends SimpleImageLoadingListener {

		private static final List<String> displayedImages = Collections.synchronizedList(new LinkedList<String>());

		@Override
		public void onLoadingComplete(String imageUri, View view, Bitmap loadedImage) {
			if (loadedImage != null) {
				ImageView imageView = (ImageView) view;
				boolean firstDisplay = !displayedImages.contains(imageUri);
				if (firstDisplay) {
					FadeInBitmapDisplayer.animate(imageView, 500);
					displayedImages.add(imageUri);
				}
			}
		}
	}
}
