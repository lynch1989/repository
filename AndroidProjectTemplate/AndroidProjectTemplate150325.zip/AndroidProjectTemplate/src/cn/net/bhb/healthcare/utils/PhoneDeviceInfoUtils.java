package cn.net.bhb.healthcare.utils;

import java.net.InetAddress;
import java.net.NetworkInterface;
import java.net.SocketException;
import java.util.ArrayList;
import java.util.Enumeration;
import java.util.List;

import android.content.Context;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.content.pm.PackageManager.NameNotFoundException;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.net.wifi.WifiInfo;
import android.net.wifi.WifiManager;
import android.os.Build;
import android.telephony.CellLocation;
import android.telephony.TelephonyManager;
import android.telephony.gsm.GsmCellLocation;
import android.util.DisplayMetrics;

/**
 * 手机硬件信息工具类
 * @author Lynch
 */
public class PhoneDeviceInfoUtils {

	/**
	 * 获得手机的品牌
	 * 
	 * @return
	 */
	public static String getBrand() {
		return Build.BRAND;
	}

	/**
	 * 获得手机的型号
	 * 
	 * @return
	 */
	public static String getModel() {
		return Build.MODEL;
	}

	/**
	 * 获得IEMEI
	 * 
	 * @param context
	 * @return
	 */
	public static String getIEMEINumber(Context context) {
		TelephonyManager telephonyManager = (TelephonyManager) context.getSystemService(Context.TELEPHONY_SERVICE);
		return telephonyManager.getDeviceId();
	}

	/**
	 * 获得手机区域码，基于基站定位
	 * 
	 * @param context
	 * @return
	 */
	public static String getphoneNumber(Context context) {
		TelephonyManager telephonyManager = (TelephonyManager) context.getSystemService(Context.TELEPHONY_SERVICE);
		CellLocation cellla = telephonyManager.getCellLocation();
		String cellnum = String.valueOf(cellla);
		return cellnum;
	}

	/**
	 * 获得运营商的名字
	 * 
	 * @param context
	 * @return
	 */
	public static String getNetworkOperatorName(Context context) {
		TelephonyManager telephonyManager = (TelephonyManager) context.getSystemService(Context.TELEPHONY_SERVICE);
		return telephonyManager.getNetworkOperatorName();
	}

	/**
	 * 获得操作系统版本号
	 * 
	 * @return
	 */
	public static String getSystemVersion() {
		return Build.VERSION.RELEASE;
	}

	/**
	 * 判断网络是否打开
	 * 
	 * @param context
	 * @return
	 */

	public static boolean isConnNET(Context context) {
		boolean bisConnFlag = false;
		ConnectivityManager conManager = (ConnectivityManager) context.getSystemService(Context.CONNECTIVITY_SERVICE);
		NetworkInfo network = conManager.getActiveNetworkInfo();
		if (network != null) {
			bisConnFlag = conManager.getActiveNetworkInfo().isAvailable();
		}
		return bisConnFlag;
	}

	/**
	 * 返回网络类型
	 * 
	 * @param context
	 * @return
	 */
	public static String getNetworkType(Context context) {
		ConnectivityManager connectivityManager = (ConnectivityManager) context.getSystemService(Context.CONNECTIVITY_SERVICE);
		NetworkInfo networkInfo = connectivityManager.getActiveNetworkInfo();
		return networkInfo.getTypeName();
	}

	/**
	 * 获得IP地址
	 * 
	 * @param context
	 * @return
	 */
	public static String getIP(Context context) {
		String ipAddress = null;
		if ("WIFI".equals(getNetworkType(context))) { // 获得wifi下的ip地址
			WifiManager wifiManager = (WifiManager) context.getSystemService(Context.WIFI_SERVICE);
			WifiInfo wifiInfo = wifiManager.getConnectionInfo();
			ipAddress = intToIp(wifiInfo.getIpAddress());
		} else { // 获得非wifi下的ip地址
			try {
				for (Enumeration<NetworkInterface> en = NetworkInterface.getNetworkInterfaces(); en.hasMoreElements();) {
					NetworkInterface intf = en.nextElement();
					for (Enumeration<InetAddress> enumIpAddr = intf.getInetAddresses(); enumIpAddr.hasMoreElements();) {
						InetAddress inetAddress = enumIpAddr.nextElement();
						if (!inetAddress.isLoopbackAddress()) {
							return inetAddress.getHostAddress().toString();
						}
					}
				}
			} catch (SocketException ex) {
				ex.printStackTrace();
			}
		}
		return ipAddress;
	}

	private static String intToIp(int i) {
		return (i & 0xFF) + "." + ((i >> 8) & 0xFF) + "." + ((i >> 16) & 0xFF)
				+ "." + (i >> 24 & 0xFF);
	}

	/**
	 * 得到CellID
	 * 
	 * @param context
	 * @return
	 */
	public static String getCellID(Context context) {
		TelephonyManager telephonyManager = (TelephonyManager) context.getSystemService(Context.TELEPHONY_SERVICE);
		GsmCellLocation gsmCellLocation = (GsmCellLocation) telephonyManager.getCellLocation();
		return gsmCellLocation.getCid() + "";
	}

	/**
	 * 获得屏幕的物理尺寸
	 * 
	 * @return
	 */

	public static String getScreenSizeString(Context cx) {
		String size = "";
		DisplayMetrics dm = new DisplayMetrics();
		dm = cx.getApplicationContext().getResources().getDisplayMetrics();
		int screenWidth = dm.widthPixels;
		int screenHeight = dm.heightPixels;
		String w = String.valueOf(screenWidth);
		String h = String.valueOf(screenHeight);
		size = w + "x" + h;
		// if ("480".equals(w) && "800".equals(he)) {
		// size= "480x800";
		// } else if("720".equals(w) && "1280".equals(he)) {
		// size= "720x1280";
		// }
		return size;

	}

	/**
	 * 获得屏幕的物理尺寸
	 * 
	 * @return
	 */

	public static List<String> getScreenSize(Context cx) {
		DisplayMetrics dm = new DisplayMetrics();
		dm = cx.getApplicationContext().getResources().getDisplayMetrics();
		int screenWidth = dm.widthPixels;
		int screenHeight = dm.heightPixels;
		String wi = String.valueOf(screenWidth);
		String he = String.valueOf(screenHeight);
		List<String> list = new ArrayList<String>();
		list.add(wi);
		list.add(he);
		return list;
	}

	/**
	 * 获得屏幕的物理尺寸
	 * 
	 * @return
	 */

	public static int[] getScreenSizeInt(Context cx) {
		DisplayMetrics dm = new DisplayMetrics();
		dm = cx.getApplicationContext().getResources().getDisplayMetrics();
		int screenWidth = dm.widthPixels;
		int screenHeight = dm.heightPixels;
		int[] mysize = new int[2];
		mysize[0] = screenWidth;
		mysize[1] = screenHeight;
		return mysize;
	}

	/**
	 * 获取应用版本号
	 * 
	 * @return 版本号
	 */

	public static String getAppVersion(Context context) {

		PackageManager pm = context.getPackageManager();
		try {
			PackageInfo pack = pm.getPackageInfo(context.getPackageName(), 0);
			return pack.versionName;
		} catch (NameNotFoundException e) {
			e.printStackTrace();
			return "";
		}
	}

	/**
	 * 根据手机的分辨率从 px(像素) 的单位 转成为 dp
	 */
	public static int px2dip(Context context, float pxValue) {
		final float scale = context.getResources().getDisplayMetrics().density;
		return (int) (pxValue / scale + 0.5f);
	}

	/**
	 * 根据手机的分辨率从 dp 的单位 转成为 px(像素)
	 */
	public static int dip2px(Context context, float dpValue) {
		final float scale = context.getResources().getDisplayMetrics().density;
		return (int) (dpValue * scale + 0.5f);
	}
}
