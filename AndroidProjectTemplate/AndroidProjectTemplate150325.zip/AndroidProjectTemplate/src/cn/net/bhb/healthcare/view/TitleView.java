package cn.net.bhb.healthcare.view;

import android.app.Activity;
import android.content.Context;
import android.util.AttributeSet;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;
import cn.net.bhb.healthcare.R;

/**
 * 自定义标题栏
 * 1. 如果是文字，提供了setLeftText、setRightText方法
 * 2. 如果是图片，提供了setLeftImage、setRightImage方法
 * 3. 如果是其他，提供了get方法
 * 4. 如果是左侧返回按钮，提供了setLeftBack方法 
 * @author Lynch
 */
public class TitleView extends FrameLayout implements View.OnClickListener {

	private RelativeLayout rlLeft;
	private TextView tvLeft;
	private ImageView ivLeft;
	private RelativeLayout rlRight;
	private TextView tvRight;
	private ImageView ivRight;
	private TextView tvTitle;
	
	public TitleView(Context context) {
		this(context, null);
	}
	
	public TitleView(Context context, AttributeSet attrs) {
		this(context, attrs, 0);
	}
	
	public TitleView(Context context, AttributeSet attrs, int defStyle) {
		super(context, attrs, defStyle);
	
		LayoutInflater inflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
		inflater.inflate(R.layout.layout_titleview, this, true);
	
		rlLeft = (RelativeLayout) findViewById(R.id.rl_left);
		tvLeft = (TextView) findViewById(R.id.tv_left);
		ivLeft = (ImageView) findViewById(R.id.iv_left);
		rlLeft.setVisibility(View.INVISIBLE);
		tvLeft.setVisibility(View.GONE);
		ivLeft.setVisibility(View.GONE);
		rlLeft.setOnClickListener(this);
		
		rlRight = (RelativeLayout) findViewById(R.id.rl_right);
		tvRight = (TextView) findViewById(R.id.tv_right);
		ivRight = (ImageView) findViewById(R.id.iv_right);
		rlRight.setVisibility(View.INVISIBLE);
		tvRight.setVisibility(View.GONE);
		ivRight.setVisibility(View.GONE);
		rlRight.setOnClickListener(this);
		
		tvTitle = (TextView) findViewById(R.id.tv_text);
		tvTitle.setVisibility(View.INVISIBLE);
	}
	
	@Override
	public void onClick(View v) {
		switch (v.getId()) {
		case R.id.rl_left:
			if(mOnLeftButtonClickListener != null)
				mOnLeftButtonClickListener.onClick(v);
			break;
		case R.id.rl_right:
			if(mOnRightButtonClickListener != null)
				mOnRightButtonClickListener.onClick(v);
			break;
		}
	}
	
	/**
	 * 左侧按钮点击监听
	 */
	private OnLeftButtonClickListener mOnLeftButtonClickListener;
	/**
	 * 右侧按钮点击监听
	 */
	private OnRightButtonClickListener mOnRightButtonClickListener;

	/**
	 * 左侧按钮点击监听接口
	 */
	public interface OnLeftButtonClickListener {
		public void onClick(View v);
	}

	/**
	 * 右侧侧按钮点击监听接口
	 */
	public interface OnRightButtonClickListener {
		public void onClick(View v);
	}
	
	//---------------------左侧按钮start----------------------------------------
	/**
	 * 设置左侧文本按钮
	 * @param text
	 * @param listener
	 */
	public void setLeftText(String text, OnLeftButtonClickListener listener) {
		tvLeft.setText(text);
		rlLeft.setVisibility(View.VISIBLE);
		tvLeft.setVisibility(View.VISIBLE);
		ivLeft.setVisibility(View.GONE);
		mOnLeftButtonClickListener = listener;
	}
	
	/**
	 * 设置左侧文本按钮
	 * @param resId
	 * @param listener
	 */
	public void setLeftText(int resId, OnLeftButtonClickListener listener) {
		tvLeft.setText(resId);
		rlLeft.setVisibility(View.VISIBLE);
		tvLeft.setVisibility(View.VISIBLE);
		ivLeft.setVisibility(View.GONE);
		mOnLeftButtonClickListener = listener;
	}
	
	/**
	 * 设置左侧文本按钮字体颜色和字体大小
	 * @param text
	 * @param textColor
	 * @param textSize
	 * @param listener
	 */
	public void setLeftText(String text, int textColor, int textSize, OnLeftButtonClickListener listener) {
		setLeftText(text, listener);
		tvLeft.setTextColor(textColor);
		tvLeft.setTextSize(textSize);
	}
	
	/**
	 * 设置左侧文本按钮字体颜色和字体大小
	 * @param text
	 * @param textColor
	 * @param textSize
	 * @param listener
	 */
	public void setLeftText(int resId, int textColor, int textSize, OnLeftButtonClickListener listener) {
		setLeftText(resId, listener);
		tvLeft.setTextColor(textColor);
		tvLeft.setTextSize(textSize);
	}
	
	/**
	 * 获取左侧文本按钮
	 * @return
	 */
	public TextView getLeftTextView(){
		return tvLeft;
	}
	
	/**
	 * 设置左侧图片按钮
	 * @param resId
	 * @param listener
	 */
	public void setLeftImage(int resId, OnLeftButtonClickListener listener) {
		tvLeft.setBackgroundResource(resId);
		rlLeft.setVisibility(View.VISIBLE);
		tvLeft.setVisibility(View.GONE);
		ivLeft.setVisibility(View.VISIBLE);
		mOnLeftButtonClickListener = listener;
	}
	
	/**
	 * 获取左侧图片按钮
	 * @return
	 */
	public ImageView getLeftImageView(){
		return ivLeft;
	}
	
	/**
	 * 去除左侧按钮（文本和图片）
	 */
	public void removeLeftButton() {
		tvLeft.setText("");
		rlLeft.setVisibility(View.INVISIBLE);
		tvLeft.setVisibility(View.GONE);
		ivLeft.setVisibility(View.GONE);
		mOnLeftButtonClickListener = null;
	}
	
	/**
	 * 隐藏左侧按钮
	 */
	public void hiddenLeftButton() {
		rlLeft.setVisibility(View.INVISIBLE);
	}
	
	/**
	 * 显示左侧按钮
	 */
	public void showLeftButton() {
		rlLeft.setVisibility(View.VISIBLE);
	}
	
	/**
	 * 设置左侧后退按钮
	 * @param activity
	 * @param isVertical
	 */
	public void setLeftBackImage(final Activity activity, final boolean isVertical){
		rlLeft.setVisibility(View.VISIBLE);
		tvLeft.setVisibility(View.GONE);;
		ivLeft.setVisibility(View.VISIBLE);
		ivLeft.setBackgroundResource(R.drawable.jiantou2);
		OnClickListener ivLeftBackListener = new OnClickListener() {
			@Override
			public void onClick(View v) {
				activity.finish();
				if(isVertical){
					activity.overridePendingTransition(0, R.anim.exit_top_bottom);
				}else{
					activity.overridePendingTransition(0, R.anim.exit_left_right);
				}
			}
		};
		rlLeft.setOnClickListener(ivLeftBackListener);
	}
	//---------------------左侧按钮end----------------------------------------
	
	//---------------------右侧按钮start----------------------------------------
	/**
	 * 设置右侧文本按钮
	 * @param text
	 * @param listener
	 */
	public void setRightText(String text, OnRightButtonClickListener listener) {
		tvRight.setText(text);
		rlRight.setVisibility(View.VISIBLE);
		tvRight.setVisibility(View.VISIBLE);
		ivRight.setVisibility(View.GONE);
		mOnRightButtonClickListener = listener;
	}
	
	/**
	 * 设置右侧文本按钮
	 * @param resId
	 * @param listener
	 */
	public void setRightText(int resId, OnRightButtonClickListener listener) {
		tvRight.setText(resId);
		rlRight.setVisibility(View.VISIBLE);
		tvRight.setVisibility(View.VISIBLE);
		ivRight.setVisibility(View.GONE);
		mOnRightButtonClickListener = listener;
	}
	
	/**
	 * 设置右侧文本按钮字体颜色和字体大小
	 * @param text
	 * @param textColor
	 * @param textSize
	 * @param listener
	 */
	public void setRightText(String text, int textColor, int textSize, OnRightButtonClickListener listener) {
		setRightText(text, listener);
		tvRight.setTextColor(textColor);
		tvRight.setTextSize(textSize);
	}
	
	/**
	 * 设置右侧文本按钮字体颜色和字体大小
	 * @param resId
	 * @param textColor
	 * @param textSize
	 * @param listener
	 */
	public void setRightText(int resId, int textColor, int textSize, OnRightButtonClickListener listener) {
		setRightText(resId, listener);
		tvRight.setTextColor(textColor);
		tvRight.setTextSize(textSize);
	}
	
	/**
	 * 获取右侧文本按钮
	 * @return
	 */
	public TextView getRightTextView(){
		return tvRight;
	}
	
	/**
	 * 设置右侧图片按钮
	 * @param resId
	 * @param listener
	 */
	public void setRightImage(int resId, OnRightButtonClickListener listener) {
		tvRight.setBackgroundResource(resId);
		rlRight.setVisibility(View.VISIBLE);
		tvRight.setVisibility(View.GONE);
		ivRight.setVisibility(View.VISIBLE);
		mOnRightButtonClickListener = listener;
	}
	
	/**
	 * 获取右侧图片按钮
	 * @return
	 */
	public ImageView getRightImageView(){
		return ivRight;
	}
	
	/**
	 * 去除右侧按钮（文本和图片）
	 */
	public void removeRightButton() {
		tvRight.setText("");
		rlRight.setVisibility(View.INVISIBLE);
		tvRight.setVisibility(View.GONE);
		ivRight.setVisibility(View.GONE);
		mOnRightButtonClickListener = null;
	}
	
	/**
	 * 隐藏右侧按钮
	 */
	public void hiddenRightButton() {
		rlRight.setVisibility(View.INVISIBLE);
	}
	
	/**
	 * 显示右侧按钮
	 */
	public void showRightButton() {
		rlRight.setVisibility(View.VISIBLE);
	}
	//---------------------右侧按钮end----------------------------------------
	
	//---------------------中间标题start----------------------------------------
	/**
	 * 设置标题
	 * @param text
	 */
	public void setTitle(String text) {
		tvTitle.setVisibility(View.VISIBLE);
		tvTitle.setText(text);
	}
	
	/**
	 * 设置标题
	 * @param resId
	 */
	public void setTitle(int resId) {
		tvTitle.setText(resId);
		tvTitle.setVisibility(View.VISIBLE);
	}
	
	/**
	 * 设置标题字体颜色和字体大小
	 * @param text
	 * @param textColor
	 * @param textSize
	 */
	public void setTitle(String text, int textColor, int textSize) {
		setTitle(text);
		tvTitle.setTextColor(textColor);
		tvTitle.setTextSize(textSize);
	}
	//---------------------中间标题end----------------------------------------
}
