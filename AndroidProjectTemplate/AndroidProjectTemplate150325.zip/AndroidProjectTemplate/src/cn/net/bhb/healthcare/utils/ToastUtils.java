package cn.net.bhb.healthcare.utils;

import android.app.Activity;
import android.content.Context;
import android.widget.Toast;

/**
 * Toast工具类
 * @author Lynch
 */
public class ToastUtils {
	
	/**
	 * 获取消息字符串
	 * @param context
	 * @param msg
	 * @return
	 */
	public static String getMessage(final Context context, final Object msg){
		String _msg = "";
		if (msg instanceof Integer) {
			//字符串资源
			_msg = context.getResources().getString((Integer) msg);
		} else if (msg instanceof String) {
			//字符串
			_msg = (String) msg;
		}
		return _msg;
	}

	/**
	 * 弹出短时间显示的Toast
	 * @param context
	 * @param text
	 */
	public static void showShort(final Context context, final Object msg) {
		Toast.makeText(context, getMessage(context, msg), Toast.LENGTH_SHORT).show();
	}

	/**
	 * 弹出长时间显示的Toast
	 * @param context
	 * @param text
	 */
	public static void showLong(final Context context, final Object msg) {
		Toast.makeText(context, getMessage(context, msg), Toast.LENGTH_LONG).show();
	}
	
	/**
	 * 在不是主线程的线程中弹出Toast
	 * @param activity
	 * @param msg
	 */
	public static void showShortOnBackground(final Activity activity, final Object msg) {
		activity.runOnUiThread(new Runnable() {
			@Override
			public void run() {
				showShort(activity, msg);
			}
		});
	}
}
