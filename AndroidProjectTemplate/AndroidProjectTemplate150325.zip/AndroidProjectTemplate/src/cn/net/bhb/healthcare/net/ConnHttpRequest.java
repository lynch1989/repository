package cn.net.bhb.healthcare.net;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.HttpStatus;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.HttpClient;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.conn.ConnectTimeoutException;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.message.BasicNameValuePair;
import org.apache.http.params.BasicHttpParams;
import org.apache.http.params.HttpConnectionParams;
import org.apache.http.params.HttpParams;
import org.apache.http.util.EntityUtils;

import cn.net.bhb.healthcare.GlobalVariables;

import com.lidroid.xutils.http.client.multipart.MultipartEntity;
import com.lidroid.xutils.http.client.multipart.content.FileBody;
import com.lidroid.xutils.http.client.multipart.content.StringBody;

/**
 * 网络连接工具类 主要负责与服务器建立连接、执行post或get请求
 * @author Lynch
 */
public class ConnHttpRequest {
	
	public static int TIME_OUT = 8000;
	private HttpClient client;
	private HttpPost post;
	private HttpGet get;
	private HttpResponse response;

	public ConnHttpRequest() {
		client = new DefaultHttpClient();
	}

	/**
	 * Post请求与服务器端进行数据交互
	 * @param uri 请求的地址
	 * @param params 请求参数
	 * @return JSON数据格式的字符串
	 * @throws ErrorException 
	 */
	public String sendPost(String uri, Map<String, String> params) throws ErrorException {
		post = new HttpPost(uri);

		// 处理超时
		HttpParams httpParams = new BasicHttpParams();//
		httpParams = new BasicHttpParams();
		HttpConnectionParams.setConnectionTimeout(httpParams, TIME_OUT);
		HttpConnectionParams.setSoTimeout(httpParams, TIME_OUT);
		post.setParams(httpParams);

		// 设置参数
		if (params != null && params.size() > 0) {
			List<BasicNameValuePair> parameters = new ArrayList<BasicNameValuePair>();
			for (Map.Entry<String, String> item : params.entrySet()) {
				BasicNameValuePair pair = new BasicNameValuePair(item.getKey(), item.getValue());
				parameters.add(pair);
			}
			try {
				UrlEncodedFormEntity entity = new UrlEncodedFormEntity(parameters, GlobalVariables.Encoding);
				post.setEntity(entity);
			} catch (Exception e) {
				e.printStackTrace();
			}
		}

		try {
			response = client.execute(post);
			if (response.getStatusLine().getStatusCode() == 200) {
				return EntityUtils.toString(response.getEntity(), GlobalVariables.Encoding);
			} else {
				throw new ErrorException(ErrorException.Ex_ResponseCode, response.getStatusLine().getStatusCode()+"");
			}
		} catch (ClientProtocolException e) {
			e.printStackTrace();
			throw new ErrorException(ErrorException.Ex_Connection, e.getMessage());
		} catch (IOException e) {
			e.printStackTrace();
			throw new ErrorException(ErrorException.Ex_Connection, e.getMessage());
		}
	}

	/**
	 * Get请求与服务器端进行数据交互
	 * @param uri 请求的地址
	 * @param params 请求参数
	 * @return JSON数据格式的字符串
	 * @throws ErrorException 
	 */
	public String sendGet(String uri, Map<String, String> params) throws ErrorException {
		// 拼接参数
		StringBuffer requestParams = new StringBuffer();
		if (params != null && params.size() > 0) {
			for (Entry<String, String> item : params.entrySet()) {
				requestParams.append(item.getKey() + "=" + item.getValue() + "&");
			}
		}
		String resultParam = requestParams.toString();
		// 去除uri参数中最后一个&
		if (resultParam.endsWith("&")) {
			resultParam = resultParam.substring(0, resultParam.length() - 1);
		}
		
		get = new HttpGet(uri + "?" + resultParam);
		
		// 处理超时
		HttpParams httpParams = new BasicHttpParams();//
		httpParams = new BasicHttpParams();
		HttpConnectionParams.setConnectionTimeout(httpParams, TIME_OUT);
		HttpConnectionParams.setSoTimeout(httpParams, TIME_OUT);
		get.setParams(httpParams);

		try {
			response = client.execute(get);
			if (response.getStatusLine().getStatusCode() == 200) {
				return EntityUtils.toString(response.getEntity(), GlobalVariables.Encoding);
			}else {
				throw new ErrorException(ErrorException.Ex_ResponseCode,response.getStatusLine().getStatusCode()+"");
			}
		} catch (ClientProtocolException e) {
			e.printStackTrace();
			throw new ErrorException(ErrorException.Ex_Connection,e.getMessage());
		}  catch (ConnectTimeoutException e) {
			e.printStackTrace();
			throw new ErrorException(ErrorException.Ex_TimeOut, e.getMessage());
		}   catch (IOException e) {
			e.printStackTrace();
			throw new ErrorException(ErrorException.Ex_Connection,e.getMessage());
		}
	}

	/**
	 * 提交参数里有文件的数据
	 * @param url 服务器地址
	 * @param param 请求参数
	 * @return 服务器返回结果
	 * @throws Exception
	 */
	public String uploadSubmit(String url, Map<String, String> param, String fileKey, File fileValue) {
		post = new HttpPost(url);
		
		StringBuffer sb = new StringBuffer();
		try {
			MultipartEntity entity = new MultipartEntity();
			if (param != null && !param.isEmpty()) {
				for (Map.Entry<String, String> entry : param.entrySet()) {
					if (entry.getValue() != null
							&& entry.getValue().trim().length() > 0) {
						entity.addPart(entry.getKey(),
								new StringBody(entry.getValue()));
					}
				}
			}
			// 添加文件参数
			if (fileValue != null && fileValue.exists()) {
				entity.addPart(fileKey, new FileBody(fileValue));
			} else {
				throw new FileNotFoundException();
			}
			post.setEntity(entity);
			HttpResponse response = client.execute(post);
			int stateCode = response.getStatusLine().getStatusCode();
			if (stateCode == HttpStatus.SC_OK) {
				HttpEntity result = response.getEntity();
				if (result != null) {
					InputStream is = result.getContent();
					BufferedReader br = new BufferedReader(
							new InputStreamReader(is));
					String tempLine;
					while ((tempLine = br.readLine()) != null) {
						sb.append(tempLine);
					}
				}
			}
			post.abort();
		} catch (Exception e) {
		}
		return sb.toString();
	}
}
