package cn.net.bhb.healthcare.utils;

import java.text.DecimalFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import android.annotation.SuppressLint;
import android.text.TextUtils;

/**
 * 字符串工具类
 * @author Lynch
 */
public class StringUtils {
	
	/**
	 * 格式化文件大小，不保留末尾的0
	 * @param len
	 * @return
	 */
	public static String formatFileSize(long len) {
		return formatFileSize(len, false);
	}

	/**
	 * 格式化文件大小，保留末尾的0，达到长度一致
	 * @param len
	 * @param keepZero
	 * @return
	 */
	public static String formatFileSize(long len, boolean keepZero) {
		String size;
		DecimalFormat formatKeepTwoZero = new DecimalFormat("#.00");
		DecimalFormat formatKeepOneZero = new DecimalFormat("#.0");
		if (len < 1024) {
			size = String.valueOf(len + "B");
		} else if (len < 10 * 1024) {
			// [0, 10KB)，保留两位小数
			size = String.valueOf(len * 100 / 1024 / (float) 100) + "KB";
		} else if (len < 100 * 1024) {
			// [10KB, 100KB)，保留一位小数
			size = String.valueOf(len * 10 / 1024 / (float) 10) + "KB";
		} else if (len < 1024 * 1024) {
			// [100KB, 1MB)，个位四舍五入
			size = String.valueOf(len / 1024) + "KB";
		} else if (len < 10 * 1024 * 1024) {
			// [1MB, 10MB)，保留两位小数
			if (keepZero) {
				size = String.valueOf(formatKeepTwoZero.format(len * 100 / 1024
						/ 1024 / (float) 100))
						+ "MB";
			} else {
				size = String.valueOf(len * 100 / 1024 / 1024 / (float) 100)
						+ "MB";
			}
		} else if (len < 100 * 1024 * 1024) {
			// [10MB, 100MB)，保留一位小数
			if (keepZero) {
				size = String.valueOf(formatKeepOneZero.format(len * 10 / 1024
						/ 1024 / (float) 10))
						+ "MB";
			} else {
				size = String.valueOf(len * 10 / 1024 / 1024 / (float) 10)
						+ "MB";
			}
		} else if (len < 1024 * 1024 * 1024) {
			// [100MB, 1GB)，个位四舍五入
			size = String.valueOf(len / 1024 / 1024) + "MB";
		} else {
			// [1GB, ...)，保留两位小数
			size = String.valueOf(len * 100 / 1024 / 1024 / 1024 / (float) 100)
					+ "GB";
		}
		return size;
	}
	
	/**
	 * 判断是否是数字
	 * @param str
	 * @return
	 */
	public static boolean isNumeric(String str) {  
		Pattern pattern = Pattern.compile("[0-9]*");
		Matcher isNum = pattern.matcher(str);
		if( !isNum.matches() ) {
			return false;
		}
		return true;
	}
	
	/**
	 * 获取当前时间
	 * @return 返回短时间字符串格式yyyy-MM-dd HH:mm:ss
	 */
	@SuppressLint("SimpleDateFormat")
	public static String getCurrentTime() {
		SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		String dateString = formatter.format(new Date());
		return dateString;
	}
	
	/**
	 * 获取当前时间
	 * @param format 短时间字符串格式
	 * @return 返回短时间字符串格式yyyy-MM-dd HH:mm:ss
	 */
	@SuppressLint("SimpleDateFormat")
	public static String getCurrentTime(String format){
		SimpleDateFormat formatter = new SimpleDateFormat(format);
		String dateString = formatter.format(new Date());
		return dateString;
	}
	
	/**
	 * 将时间time从一种格式format1转为另一种格式format2
	 * @param time
	 * @param format1
	 * @param format2
	 * @return
	 */
	@SuppressLint("SimpleDateFormat")
	public static String formatTime(String time, String format1, String format2){
		String ret = "";
		if(!TextUtils.isEmpty(time) && !TextUtils.isEmpty(format1) && !TextUtils.isEmpty(format2)){
			try {
				ret = new SimpleDateFormat(format2).format(new SimpleDateFormat(format1).parse(time));
			} catch (ParseException e) {
				e.printStackTrace();
				ret = time; 
			}
		}else{
			ret = time;
		}
		return ret;
	}
	
	/**
	 * 转换时间显示
	 * @param time 格式：2015-03-05 15:37:20
	 * @return
	 */
	public static String convertTime(String t) {
		String str = t;
		String today = getCurrentTime("yyyy-MM-dd");
		String time = formatTime(t, "yyyy-MM-dd HH:mm:ss", "yyyy-MM-dd");
		if (!TextUtils.isEmpty(t) && !TextUtils.isEmpty(time)) {
			if (today.equals(time)) {
				str = formatTime(t, "yyyy-MM-dd HH:mm:ss", "HH:mm");
			} else {
				str = formatTime(t, "yyyy-MM-dd HH:mm:ss", "MM月dd日");
			}
		}
		return str;
	}
	
	/**
	 * 字符串List集合转换为字符串，分隔符为英文逗号“,”
	 */
	public static String list2String(List<String> list){
		return list2String(list, ",");
	}
	
	/**
	 * 字符串List集合转换为字符串
	 */
	public static String list2String(List<String> list, String delimiter){
		String text = "";
		if(list != null && list.size() > 0){
			for(int i = 0; i < list.size(); i++){
				if(!TextUtils.isEmpty(text)){
					text += delimiter;
				}
				text += list.get(i);
			}
		}
		return text;
	}
	
	/**
	 * 字符串转换为字符串List集合，分隔符为英文逗号“,”
	 */
	public static List<String> string2List(String str){
		return string2List(str, ",");
	}
	
	/**
	 * 字符串转换为字符串List集合
	 */
	public static List<String> string2List(String str, String delimiter){
		List<String> list = new ArrayList<String>();
		if(!TextUtils.isEmpty(str)){
			String[] arr = str.split(delimiter);
			for(int i = 0; i < arr.length; i++){
				list.add(arr[i]);
			}
		}
		return list;
	}
	
	/**
	 * 字符串数组转换为字符串，分隔符为英文逗号“,”
	 */
	public static String array2String(String[] arr){
		return array2String(arr, ",");
	}
	
	/**
	 * 字符串数组转换为字符串
	 * @param arr 字符串数组
	 * @param delimiter 分隔符
	 */
	public static String array2String(String[] arr, String delimiter){
		StringBuilder sb = new StringBuilder();
		if(arr != null){
			int len = arr.length;
			for(int i = 0; i < len; i++){
				sb.append(arr[i]);
				if(i != len - 1){
					sb.append(delimiter);
				}
			}
		}
		return sb.toString();
	}
}
