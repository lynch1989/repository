package cn.lynch.newstemplate.fragment;

import java.util.ArrayList;
import java.util.List;

import android.app.Activity;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.Handler;
import android.support.v4.app.Fragment;
import android.support.v4.view.ViewPager;
import android.support.v4.view.ViewPager.OnPageChangeListener;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewGroup.LayoutParams;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import cn.lynch.newstemplate.R;
import cn.lynch.newstemplate.activity.HomeActivity;
import cn.lynch.newstemplate.bean.News;
import cn.lynch.newstemplate.bean.ViewPagerImage;
import cn.lynch.newstemplate.http.protocol.ViewPagerImageProtocol;
import cn.lynch.newstemplate.utils.AndroidUtils;
import cn.lynch.newstemplate.utils.CrashHandler;
import cn.lynch.newstemplate.view.commonadapter.CommonAdapter;
import cn.lynch.newstemplate.view.commonadapter.ViewHolder;
import cn.lynch.newstemplate.view.loopviewpager.LoopViewPagerAdapter;

public class HeadlinesFragment extends Fragment {

	private HomeActivity mHomeActivity;
	private View view;
	private ViewPager mLoopViewPager;
	private ImageView[] imageViews;// 底部小圆点
	private ImageView dotImageView;
	private LinearLayout mViewPoints;
	private int startPos = 0;
	private Handler mHandler;
	private Runnable viewpagerRunnable;
	private static final int TIME = 5000;
	
	private boolean loopFlag = false;
	private boolean isViewPagerShow = false;
	private ListView mListView;
	private List<News> mListViewData = new ArrayList<News>();
	private CommonAdapter mListViewAdapter;

	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
	}

	@Override
	public void onAttach(Activity activity) {
		mHomeActivity = (HomeActivity) getActivity();
		new CrashHandler(mHomeActivity);
		super.onAttach(activity);
	}

	@Override
	public View onCreateView(LayoutInflater inflater, ViewGroup container,
			Bundle savedInstanceState) {
		view = inflater.inflate(R.layout.fragment_headlines, container, false);
		
		mLoopViewPager = (ViewPager) view.findViewById(R.id.headlines_viewpager_lvp);
		mListView = (ListView) view.findViewById(R.id.headlines_listview);
		
		mHandler = new Handler();
		
		showViewPager();
		showListView();
		
		return view;
	}

	@Override
	public void onStart() {
		super.onStart();
		showViewPager();
	}

	@Override
	public void onStop() {
		super.onStop();
		loopFlag = false;
		isViewPagerShow = false;
	}
	
	private void showViewPager(){
		if(!isViewPagerShow){
			isViewPagerShow = true;
			loopFlag = true;
			new ViewPagerImageAsyncTask().execute();
		}
	}

	private void showListView() {
		initListViewData();
		// 设置适配器
		mListView.setAdapter(mListViewAdapter = new CommonAdapter<News>(
				getActivity(), mListViewData, R.layout.listview_item) {
			@Override
			public void convert(ViewHolder holder, News item) {
				holder.setText(R.id.listview_textview, item.getTitle());
			}
		});
	}
	
	private void initListViewData() {
		News news = null;
		for(int i = 0; i < 50; i++){
			news = new News("新闻标题" + i, "image url");
			mListViewData.add(news);
		}
	}

	private class ViewPagerImageAsyncTask extends AsyncTask<Void, Void, List<ViewPagerImage>> {

		@Override
		protected void onPreExecute() {
		}

		@Override
		protected List<ViewPagerImage> doInBackground(Void... params) {
			ViewPagerImageProtocol protocol = new ViewPagerImageProtocol();
			return protocol.load(mHomeActivity);
		}

		@Override
		protected void onPostExecute(List<ViewPagerImage> result) {
			super.onPostExecute(result);
			if (result == null || result.size() == 0) {
				return;
			}
			if (!AndroidUtils.isNetworkConnected(mHomeActivity)) {
				return;
			}
			initLoopViewPager(result);
			initLoopViewPagerDots(view, result);
			initLoopViewPagerRunnable(); // LoopViewPager 的定时任务
		}
	}

	/**
	 * 初始化LoopViewPager
	 */
	private void initLoopViewPager(List<ViewPagerImage> result) {
		LoopViewPagerAdapter adapter = new LoopViewPagerAdapter(result, mHomeActivity);
		mLoopViewPager.setAdapter(adapter);
		mLoopViewPager.setCurrentItem(startPos);
		mLoopViewPager.setOnPageChangeListener(new OnPageChangeListener() {
			@Override
			public void onPageSelected(int position) {
				position = position % imageViews.length;
				for (int i = 0; i < imageViews.length; i++) {
					imageViews[position].setBackgroundResource(R.drawable.icon_checked);
					// 不是当前选中的page，其小圆点设置为未选中的状态
					if (position != i) {
						imageViews[i].setBackgroundResource(R.drawable.icon_unchecked);
					}
				}
			}

			@Override
			public void onPageScrolled(int arg0, float arg1, int arg2) {

			}

			@Override
			public void onPageScrollStateChanged(int status) {
			}
		});
	}

	/**
	 * 定时切换
	 */
	private void initLoopViewPagerRunnable() {
		loopFlag = true;
		viewpagerRunnable = new Runnable() {
			@Override
			public void run() {
				if(loopFlag){
					int nowIndex = mLoopViewPager.getCurrentItem();
					mLoopViewPager.setCurrentItem(nowIndex + 1);
					mHandler.postDelayed(viewpagerRunnable, TIME);
				}
			}
		};
		mHandler.postDelayed(viewpagerRunnable, TIME);
	}

	/**
	 * 初始化点
	 */
	private void initLoopViewPagerDots(View view, List<ViewPagerImage> mViewPagerImageList) {
		imageViews = new ImageView[mViewPagerImageList.size()];
		// 实例化小圆点的linearLayout和viewpager
		mViewPoints = (LinearLayout) view.findViewById(R.id.headlines_viewpager_point_ll);
		// 添加小圆点的图片
		for (int i = 0; i < mViewPagerImageList.size(); i++) {
			dotImageView = new ImageView(mHomeActivity);
			// 设置小圆点imageview的参数
			LinearLayout.LayoutParams layoutParams = new LinearLayout.LayoutParams(LayoutParams.WRAP_CONTENT, LayoutParams.WRAP_CONTENT);
			layoutParams.setMargins(10, 5, 10, 5);
			dotImageView.setLayoutParams(layoutParams);
			// 将小圆点layout添加到数组中
			imageViews[i] = dotImageView;
			// 默认选中选中状态
			if (i == startPos) {
				imageViews[i].setBackgroundResource(R.drawable.icon_checked);
			} else {
				imageViews[i].setBackgroundResource(R.drawable.icon_unchecked);
			}
			// 将imageviews添加到小圆点视图组
			mViewPoints.addView(imageViews[i]);
		}
	}
}
