package cn.lynch.newstemplate.activity;

import android.content.Intent;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentPagerAdapter;
import android.support.v4.view.ViewPager;
import android.support.v4.view.ViewPager.OnPageChangeListener;
import android.view.View;
import android.widget.Toast;
import cn.lynch.newstemplate.MyApplication;
import cn.lynch.newstemplate.R;
import cn.lynch.newstemplate.fragment.HeadlinesFragment;
import cn.lynch.newstemplate.fragment.ItemFragment;
import cn.lynch.newstemplate.view.pageindicator.TabPageIndicator;

public class HomeActivity extends BaseActivity {
	
	/**
	 * Tab标题
	 */
	private static final String[] mTabTitles = new String[] { "头条", "房产",
			"另一面", "女人", "财经", "数码", "情感", "科技" };

	@SuppressWarnings("static-access")
	@Override
	protected void onCreate(Bundle arg0) {
		super.onCreate(arg0);
		super.addView(R.layout.activity_home);
		super.setBackEnabled(false);
		super.setPageTitle("Home首页");
		super.setSearchEnabled(false);
		MyApplication app = (MyApplication) getApplication();
		app.addCurrentActivity(this);
		
		ViewPager mViewPager = (ViewPager) findViewById(R.id.pager);
		mViewPager.setAdapter(new TabPageIndicatorAdapter(getSupportFragmentManager()));
		
		TabPageIndicator mTabPageIndicator = (TabPageIndicator) findViewById(R.id.indicator);
		mTabPageIndicator.setViewPager(mViewPager);
		
		mTabPageIndicator.setOnPageChangeListener(new OnPageChangeListener() {
			
			@Override
			public void onPageSelected(int arg0) {
				Toast.makeText(HomeActivity.this, mTabTitles[arg0], Toast.LENGTH_SHORT).show();
			}
			
			@Override
			public void onPageScrolled(int arg0, float arg1, int arg2) {
				
			}
			
			@Override
			public void onPageScrollStateChanged(int arg0) {
				
			}
		});
	}
	
	/**
	 * ViewPager适配器
	 */
	class TabPageIndicatorAdapter extends FragmentPagerAdapter {
		
		public TabPageIndicatorAdapter(FragmentManager fm) {
			super(fm);
		}

		@Override
		public Fragment getItem(int position) {
			Fragment fragment = null;
			if(position == 0){
				fragment = new HeadlinesFragment();
			}else{
				// 新建一个Fragment来展示ViewPager item的内容，并传递参数
				fragment = new ItemFragment();
				Bundle args = new Bundle();
				args.putString("arg", mTabTitles[position]);
				fragment.setArguments(args);
			}
			return fragment;
		}

		@Override
		public CharSequence getPageTitle(int position) {
			return mTabTitles[position % mTabTitles.length];
		}

		@Override
		public int getCount() {
			return mTabTitles.length;
		}
	}
	
	public void openPdf(View view){
		Intent intent = new Intent(this, PdfActivity.class);
		intent.putExtra("fileName", "a.pdf");
		startActivity(intent);
	}
	
}
