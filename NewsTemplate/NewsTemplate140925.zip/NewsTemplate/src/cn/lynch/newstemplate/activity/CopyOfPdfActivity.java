package cn.lynch.newstemplate.activity;

import static java.lang.String.format;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;

import org.vudroid.core.utils.MD5StringUtil;

import android.app.Activity;
import android.app.ProgressDialog;
import android.content.DialogInterface;
import android.content.DialogInterface.OnCancelListener;
import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;
import cn.lynch.newstemplate.R;
import cn.lynch.newstemplate.utils.Constants;
import cn.lynch.newstemplate.utils.FileUtils;
import cn.lynch.newstemplate.utils.encrypt.FileDES;

import com.joanzapata.pdfview.PDFView;
import com.joanzapata.pdfview.listener.OnLoadCompleteListener;
import com.joanzapata.pdfview.listener.OnPageChangeListener;
import com.lidroid.xutils.ViewUtils;
import com.lidroid.xutils.view.annotation.ContentView;
import com.lidroid.xutils.view.annotation.ViewInject;
import com.lidroid.xutils.view.annotation.event.OnClick;

@ContentView(R.layout.activity_pdf)
public class CopyOfPdfActivity extends Activity implements OnPageChangeListener, OnLoadCompleteListener {

	@ViewInject(R.id.tv_pdf_name)
	private TextView tvPdfName;
	@ViewInject(R.id.pdfview)
	private PDFView pdfView;
	@ViewInject(R.id.et_feed_back_text)
	private EditText etFeedBackText;
	
	public static final String SAMPLE_FILE = "sample.pdf";
    public static final String ABOUT_FILE = "about.pdf";

    String pdfName = SAMPLE_FILE;
    Integer pageNumber = 1;
    
    String lastFileName = "";
    boolean showLog = true;
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		ViewUtils.inject(this);
		
		Intent intent = getIntent();
		pdfName = intent.getStringExtra("fileName");
		
		display(pdfName, false);
	}

	/**
	 * 判断assets目录下是否存在对应文件
	 * @param assetName
	 * @return
	 */
    @SuppressWarnings("unused")
	private boolean isAssetFileExist(String assetName) {
		try {
			return CopyOfPdfActivity.this.getAssets().open(pdfName) != null;
		} catch (IOException e) {
			e.printStackTrace();
		}
		return false;
	}

    ProgressDialog pd;
	/**
     * 显示pdf
     * @param assetFileName assets目录下文件名
     * @param jumpToFirstPage 是否跳转到第一页
     */
	private void display(final String assetFileName, final boolean jumpToFirstPage) {
		//显示加载进度框
		pd = new ProgressDialog(CopyOfPdfActivity.this);
		pd.setMessage("正在加载PDF中...");
		pd.setCancelable(true);
		pd.setOnCancelListener(new OnCancelListener() {
			@Override
			public void onCancel(DialogInterface dialog) {
				Toast.makeText(CopyOfPdfActivity.this, "aaa", 0).show();
			}
		});
		pd.show();
		
		//如果上一个查看的pdf与当前要查看的pdf名字不同，则删除上一个查看的pdf的解密后文件
		if(!TextUtils.isEmpty(lastFileName) && !lastFileName.equals(assetFileName)){
			delete(lastFileName);
		}
		
		lastFileName = assetFileName;
		
        if (jumpToFirstPage) pageNumber = 1;
        setTitle(pdfName = assetFileName);
        tvPdfName.setText(pdfName);
		
        if(!isTransfer(assetFileName)){
        	transfer(assetFileName);
        }
        File decodeFile = getDecodeFile(assetFileName);

		pdfView.fromFile(decodeFile)
//        pdfView.fromAsset(assetFileName)
                .defaultPage(pageNumber)
                .showMinimap(false)//放大pdf后是否显示小地图
			    .enableSwipe(true)//是否允许滑动翻页
			    .onLoad(CopyOfPdfActivity.this)
                .onPageChange(CopyOfPdfActivity.this)
                .load();
		
		//隐藏加载进度框
		pd.dismiss();
		pd = null;
    }
    
    /**
     * 加载完毕时调用
     */
	@Override
	public void loadComplete(int nbPages) {
		Toast.makeText(this, pdfName + " total pages: " + nbPages, Toast.LENGTH_SHORT).show();
	}
	
	/**
	 * 翻页时调用
	 */
	@Override
	public void onPageChanged(int page, int pageCount) {
		pageNumber = page;
        setTitle(format("%s %s / %s", pdfName, page, pageCount));
	}
	
	//---------------------------加密解密文件start-------------------------------
	@Override
	protected void onDestroy() {
		super.onDestroy();
		delete(lastFileName);
	}
	
	private String getFilePath(String fileName){
		String path = FileUtils.getDiskCachePath(getApplicationContext()) + File.separator + fileName;
		if(showLog){
			Log.v("TESTLOG", "getFilePath--" + path);
		}
		return path;
	}
	
	private String parseMd5String(String str){
		String md5str = MD5StringUtil.md5StringFor(str);
		if(showLog){
			Log.v("TESTLOG", "parseMd5String--" + str);
		}
		return md5str;
	}
	
	/**
	 * 删除目标文件
	 * @param lastFileName
	 */
	private void delete(String lastFileName) {
		if(TextUtils.isEmpty(lastFileName)){
			return;
		}
		if(showLog){
			Log.i("TESTLOG", "delete--" + lastFileName);
		}
		new File(getFilePath(parseMd5String(lastFileName))).delete();
	}

	/**
	 * 判断assets目录下目标文件是否已经转存到缓存目录
	 * @param assetFileName
	 * @return
	 */
	private boolean isTransfer(String assetFileName){
		File tmpFile = new File(getFilePath(parseMd5String(assetFileName + ".encode")));
		if(tmpFile.exists() && tmpFile.isFile() && tmpFile.length() > 0){
			return true;
		}
		return false;
	}
	
	/**
	 * 将assets目录下文件转存到缓存目录
	 * @param assetFileName
	 */
	private void transfer(String assetFileName){
		if(showLog){
			Log.i("TESTLOG", "transfer and encode--" + assetFileName);
		}
		try {
			FileDES fileDES = new FileDES(Constants.encryptKey);
			fileDES.doEncryptFile(getAssets().open(assetFileName), getFilePath(parseMd5String(assetFileName + ".encode")));
		} catch (IOException e) {
			e.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	/**
	 * 获取保存在缓存目录下的加密文件的解密后文件对象
	 * @param assetFileName
	 */
	private File getDecodeFile(String assetFileName){
		if(showLog){
			Log.d("TESTLOG", "getDecodeFile--" + assetFileName);
		}
		File file = new File(getFilePath(parseMd5String(assetFileName)));
		try {
			FileDES fileDES = new FileDES(Constants.encryptKey);
			fileDES.doDecryptFile(new FileInputStream(new File(getFilePath(parseMd5String(assetFileName + ".encode")))), file.getAbsolutePath());
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		}
		return file;
	}
	//---------------------------加密解密文件end-------------------------------

	/**
	 * 按后退键时：若当前显示不是第1页，则跳转到第1页；若是第1页，则推出Activity
	 */
    @Override
    public void onBackPressed() {
		if (pageNumber != 1) {
			pdfView.jumpTo(1);
		} else {
			super.onBackPressed();
		}
    }

	/**
	 * 发送评论按钮
	 * @param v
	 */
	@OnClick(R.id.bt_feed_back_post)
	public void postFeedBack(View v){
		String text = etFeedBackText.getText().toString().trim();
		Toast.makeText(CopyOfPdfActivity.this, "get feed back: " + text, Toast.LENGTH_LONG).show();
	}
	
	/**
	 * 切换显示a.pdf
	 * @param v
	 */
	@OnClick(R.id.bt_open_a)
	public void openA(View v){
		pdfName = "a.pdf";
		display(pdfName, true);
	}
	
	/**
	 * 切换显示about.pdf
	 * @param v
	 */
	@OnClick(R.id.bt_open_about)
	public void openAbout(View v){
		pdfName = ABOUT_FILE;
		display(pdfName, true);
	}
	
	/**
	 * 切换显示sample.pdf
	 * @param v
	 */
	@OnClick(R.id.bt_open_sample)
	public void openSample(View v){
		pdfName = SAMPLE_FILE;
		display(pdfName, true);
	}
}
