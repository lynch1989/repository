package cn.lynch.newstemplate.activity;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.widget.TextView;

public class NewsDetailActivity extends Activity {

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		
		Intent intent = getIntent();
		String id = intent.getStringExtra("id");
		String activity_id = intent.getStringExtra("activity_id");
		
		TextView tv = new TextView(this);
		tv.setText("id=" + id + ", activity_id=" + activity_id);
		
		setContentView(tv);
	}
}
