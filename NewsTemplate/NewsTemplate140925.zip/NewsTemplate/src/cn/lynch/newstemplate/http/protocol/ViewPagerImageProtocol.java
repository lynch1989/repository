package cn.lynch.newstemplate.http.protocol;

import java.util.ArrayList;
import java.util.HashMap;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import cn.lynch.newstemplate.bean.ViewPagerImage;
import cn.lynch.newstemplate.utils.URLUtils;

public class ViewPagerImageProtocol extends BaseGetProtocol<ArrayList<ViewPagerImage>> {

	@Override
	protected String getKey() {
		return URLUtils.RECOMMEND_URL;
	}

	@Override
	protected ArrayList<ViewPagerImage> parseFromJson(String json) {
		ArrayList<ViewPagerImage> mViewPagerImageList = new ArrayList<ViewPagerImage>();
		try {
			JSONArray array = new JSONArray(json);
			for (int i = 0; i < array.length(); i++) {
				JSONObject jsonObject = array.getJSONObject(i);
				ViewPagerImage recommend = new ViewPagerImage();
				recommend.setImage_url(jsonObject.getString("image_url"));
				recommend.setType(jsonObject.getString("type"));
				recommend.setLink(jsonObject.getString("link"));
				mViewPagerImageList.add(recommend);
			}
			return mViewPagerImageList;
		} catch (JSONException e) {
			e.printStackTrace();
		}
		return null;
	}

	@Override
	protected String getParames() {
		HashMap<String, String> params = new HashMap<String, String>();
		StringBuffer queryString = null;
		params.put("platform", "0");
		if (params != null && params.size() > 0) {
			queryString = new StringBuffer("?");
			queryString = joinParam(params, queryString);
		}
		return queryString.toString();
	}
}
