package cn.lynch.newstemplate.http.protocol;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.util.Iterator;
import java.util.Map;
import java.util.Map.Entry;

import android.content.Context;
import android.os.SystemClock;
import cn.lynch.newstemplate.http.HttpHelper;
import cn.lynch.newstemplate.http.HttpHelper.HttpResult;
import cn.lynch.newstemplate.utils.AndroidUtils;
import cn.lynch.newstemplate.utils.FileUtils;
import cn.lynch.newstemplate.utils.IOUtils;
import cn.lynch.newstemplate.utils.LogUtils;

public abstract class BaseGetProtocol<Data> {

	public static final String cachePath = "";

	/**
	 * 加载协议
	 */
	public Data load(Context context) {
		SystemClock.sleep(1000);// 休息1秒，防止加载过快，看不到界面变化效果
		String json = null;
		// 1.如果网络状态正常从网络获取
		if (AndroidUtils.isNetworkConnected(context)) {
			json = loadFromNetByGet();
			if (json == null) {
				// 网络出错
				return null;
			} else {
				// 3.把数据保存到本地保存到本地
				saveToLocal(context, json);
			}
		} else {
			// 2、从本地加载
			json = loadFromLocal(context);
		}
		LogUtils.i("Json 数据:" + json);
		return parseFromJson(json);
	}

	/**
	 * 从本地加载协议
	 */
	protected String loadFromLocal(Context context) {
		String path = FileUtils.getCacheDir();
		BufferedReader reader = null;
		try {
			reader = new BufferedReader(new FileReader(path + getKey()
					+ getParames()));
			String line = reader.readLine();// 第一行是时间

			Long time = Long.valueOf(line);
			if (time > System.currentTimeMillis()) {// 如果时间未过期
				StringBuilder sb = new StringBuilder();
				String result;
				while ((result = reader.readLine()) != null) {
					sb.append(result);
				}
				LogUtils.i("从本地加载JSON数据成功     " + path + getKey()
						+ getParames());
				return sb.toString();
			}

		} catch (Exception e) {
			LogUtils.i("从本地加载JSON数据失败");
			LogUtils.e(e.toString());
		} finally {
			IOUtils.close(reader);
		}
		return null;
	}

	/**
	 * GET请求从网络加载协议
	 */
	protected String loadFromNetByGet() {
		String result = null;
		HttpResult httpResult = HttpHelper.get(HttpHelper.URL + getKey()
				+ getParames());
		LogUtils.i("get请求url： " + HttpHelper.URL + "   请求key： " + getKey()
				+ "   请求参数： " + getParames());
		if (httpResult != null) {
			result = httpResult.getString();
			httpResult.close();
		}
		return result;
	}

	/**
	 * 保存到本地
	 */
	protected void saveToLocal(Context context, String str) {
		String path = FileUtils.getCacheDir() + getKey().substring(1);
		FileWriter writer = null;
		try {
			File file = new File(path);
			if (!file.exists()) {
				file.mkdirs();
			}
			writer = new FileWriter(path + getParames());
			long time = System.currentTimeMillis() + 1000 * 60 * 60;// 先计算出过期时间，写入第一行
			writer.write(time + "\r\n");
			writer.write(str.toCharArray());
			writer.flush();
			LogUtils.i("保存JSON数据到本地成功   " + path + getKey() + getParames());
		} catch (Exception e) {
			LogUtils.i("保存JSON数据到本地失败---->" + e.toString());
			LogUtils.e(e);
		} finally {
			IOUtils.close(writer);
		}
	}

	/**
	 * 获取添加参数后的StringBuffer
	 */
	protected static StringBuffer joinParam(Map<String, String> params,
			StringBuffer queryString) {
		Iterator<Entry<String, String>> iterator = params.entrySet().iterator();
		while (iterator.hasNext()) {
			Entry<String, String> param = iterator.next();
			String key = param.getKey();
			String value = param.getValue();
			queryString.append(key).append('=').append(value);
			if (iterator.hasNext()) {
				queryString.append('&');
			}
		}
		return queryString;
	}

	/**
	 * 需要增加的额外参数
	 */
	protected String getParames() {
		return "";
	}

	/**
	 * 该协议的访问地址
	 */
	protected abstract String getKey();

	/**
	 * 从json中解析
	 */
	protected abstract Data parseFromJson(String json);
}
