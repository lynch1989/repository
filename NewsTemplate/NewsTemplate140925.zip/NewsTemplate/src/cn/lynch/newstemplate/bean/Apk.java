package cn.lynch.newstemplate.bean;

import java.io.Serializable;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

/**
 * 应用
 */
public class Apk implements Serializable {

	private static final long serialVersionUID = -8035858288673218429L;
	private String id;
	private String seller_email;
	private String category;
	private String official_website;
	private String description;
	private float size;
	private String icon;
	@SerializedName("versioncode")
	private String latest_version = "0";
	private String name;
	private String seller_name;
	private String update_date;
	private String average_ratings;
	private int rating;
	private String snapshots;
	private String type;
	@SerializedName("update_summary")
	private String updateSummary;
	@SerializedName("download_url")
	private String downloadUrl;
	@Expose
	@SerializedName("local_version")
	private String localVersion;
	@Expose
	@SerializedName("package_name")
	private String packageName;
	@SerializedName("update_info")
	private String updateInfo;

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public String getUpdateSummary() {
		return updateSummary;
	}

	public void setUpdateSummary(String updateSummary) {
		this.updateSummary = updateSummary;
	}

	public String getUpdateInfo() {
		return updateInfo;
	}

	public void setUpdateInfo(String updateInfo) {
		this.updateInfo = updateInfo;
	}

	public String getLocalVersion() {
		return localVersion;
	}

	public void setLocalVersion(String localVersion) {
		this.localVersion = localVersion;
	}

	public String getPackageName() {
		return packageName;
	}

	public void setPackageName(String packageName) {
		this.packageName = packageName;
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getDownloadUrl() {
		return downloadUrl;
	}

	public void setDownloadUrl(String downloadUrl) {
		this.downloadUrl = downloadUrl;
	}

	public String getSeller_email() {
		return seller_email;
	}

	public void setSeller_email(String seller_email) {
		this.seller_email = seller_email;
	}

	public String getCategory() {
		return category;
	}

	public void setCategory(String category) {
		this.category = category;
	}

	public String getOfficial_website() {
		return official_website;
	}

	public void setOfficial_website(String official_website) {
		this.official_website = official_website;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String getIcon() {
		return icon;
	}

	public void setIcon(String icon) {
		this.icon = icon;
	}

	public String getLatest_version() {
		return latest_version;
	}

	public void setLatest_version(String latest_version) {
		this.latest_version = latest_version;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getSeller_name() {
		return seller_name;
	}

	public void setSeller_name(String seller_name) {
		this.seller_name = seller_name;
	}

	public String getUpdate_date() {
		return update_date;
	}

	public void setUpdate_date(String update_date) {
		this.update_date = update_date;
	}

	public String getAverage_ratings() {
		return average_ratings;
	}

	public void setAverage_ratings(String average_ratings) {
		this.average_ratings = average_ratings;
	}

	public int getRating() {
		return rating;
	}

	public void setRating(int rating) {
		this.rating = rating;
	}

	public float getSize() {
		return size;
	}

	public void setSize(float size) {
		this.size = size;
	}

	public String getSnapshots() {
		return snapshots;
	}

	public void setSnapshots(String snapshots) {
		this.snapshots = snapshots;
	}

}
