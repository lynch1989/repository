package cn.lynch.newstemplate.utils;

import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.AsyncTask;

/**
 * 第一个参数 params 代表的是AsyncTask执行需要的参数
 */
public class LoadImageAsyncTask extends AsyncTask<String, Void, Bitmap> {
	
	private LoadImageCallBack mLoadImageCallBack;

	public LoadImageAsyncTask(LoadImageCallBack mLoadImageCallBack) {
		this.mLoadImageCallBack = mLoadImageCallBack;
	}

	public interface LoadImageCallBack {
		void beforeImageLoad();

		void afterImageLoad(Bitmap result);
	}

	/**
	 * 在异步任务执行执行调用的方法
	 */

	@Override
	protected void onPreExecute() {
		super.onPreExecute();
		// 给imageview设置一个默认的图片
		mLoadImageCallBack.beforeImageLoad();
	}

	/**
	 * 在异步任务执行完毕后 ,调用的方法
	 */
	@Override
	protected void onPostExecute(Bitmap result) {
		super.onPostExecute(result);
		// 给imageview设置下载好的图片
		mLoadImageCallBack.afterImageLoad(result);
	}

	@Override
	protected Bitmap doInBackground(String... params) {
		// 得到要下载图片的路径
		try {
			String iconpath = params[0];
			URL url = new URL(iconpath);
			HttpURLConnection conn = (HttpURLConnection) url.openConnection();
			conn.setRequestMethod("GET");
			conn.setConnectTimeout(5000);
			InputStream is = conn.getInputStream();
			Bitmap bitmap = BitmapFactory.decodeStream(is);
			return bitmap;
		} catch (Exception e) {
			e.printStackTrace();
			LogUtils.e(e.toString());
			return null;
		}
	}
}
