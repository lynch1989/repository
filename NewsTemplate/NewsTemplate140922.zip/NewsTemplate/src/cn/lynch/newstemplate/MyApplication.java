package cn.lynch.newstemplate;

import java.util.ArrayList;
import java.util.List;

import android.app.Activity;
import android.content.Context;
import android.content.pm.PackageManager;
import android.os.Handler;
import android.os.Looper;

import com.baidu.frontia.FrontiaApplication;
import com.nostra13.universalimageloader.cache.disc.naming.Md5FileNameGenerator;
import com.nostra13.universalimageloader.core.ImageLoader;
import com.nostra13.universalimageloader.core.ImageLoaderConfiguration;
import com.nostra13.universalimageloader.core.assist.QueueProcessingType;

public class MyApplication extends FrontiaApplication {
	
	@SuppressWarnings("unused")
	private String TAG = MyApplication.class.getName();

	/** 全局Context，原理是因为Application类是应用最先运行的，所以在我们的代码调用时，该值已经被赋值过了 */
	private static MyApplication mInstance;
	/** 主线程ID */
	private static int mMainThreadId = -1;
	/** 主线程ID */
	private static Thread mMainThread;
	/** 主线程Handler */
	private static Handler mMainThreadHandler;
	/** 主线程Looper */
	private static Looper mMainLooper;

	@Override
	public void onCreate() {
		mMainThreadId = android.os.Process.myTid();
		mMainThread = Thread.currentThread();
		mMainThreadHandler = new Handler();
		mMainLooper = getMainLooper();
		mInstance = this;
		super.onCreate();

		context = getApplicationContext();
		packageManager = context.getPackageManager();
		initImageLoader(context);
		
//		// 出现应用级异常时的处理
//		Thread.setDefaultUncaughtExceptionHandler(new UncaughtExceptionHandler() {
//			@Override
//			public void uncaughtException(Thread thread, Throwable throwable) {
//				new Thread(new Runnable() {
//					@Override
//					public void run() {
//						// 弹出报错并强制退出的对话框
//						if (mActivityList.size() > 0) {
//							Looper.prepare();
//							new AlertDialog.Builder(getCurrentActivity())
//									.setTitle(R.string.app_name)
//									.setMessage("程序出现异常，只能退出")
//									.setPositiveButton(
//											"确定",
//											new DialogInterface.OnClickListener() {
//												@Override
//												public void onClick(
//														DialogInterface dialog,
//														int which) {
//													// 强制退出程序
//													finish(getApplicationContext());
//												}
//											}).show();
//							Looper.loop();
//						}
//					}
//				}).start();
//				// 错误LOG
//				Log.e(TAG, throwable.getMessage(), throwable);
//			}
//		});
	}

	public static MyApplication getApplication() {
		return mInstance;
	}

	/** 获取主线程ID */
	public static int getMainThreadId() {
		return mMainThreadId;
	}

	/** 获取主线程 */
	public static Thread getMainThread() {
		return mMainThread;
	}

	/** 获取主线程的handler */
	public static Handler getMainThreadHandler() {
		return mMainThreadHandler;
	}

	/** 获取主线程的looper */
	public static Looper getMainThreadLooper() {
		return mMainLooper;
	}

	// 启动的Activity集合
	public static List<Activity> mActivityList = new ArrayList<Activity>();
	private Context context;
	private PackageManager packageManager;

	@Override
	public void onTerminate() {
		super.onTerminate();
	}

	public Context getContext(){
		return context;
	}
	
	public PackageManager getPM() {
		return packageManager;
	}

	public static void initImageLoader(Context context) {
		// This configuration tuning is custom. You can tune every option, you
		// may tune some of them,
		// or you can create default configuration by
		// ImageLoaderConfiguration.createDefault(this);
		// method.
		ImageLoaderConfiguration config = new ImageLoaderConfiguration.Builder(
				context).threadPriority(Thread.NORM_PRIORITY - 2)
				.denyCacheImageMultipleSizesInMemory()
				.diskCacheFileNameGenerator(new Md5FileNameGenerator())
				.tasksProcessingOrder(QueueProcessingType.LIFO)
				.writeDebugLogs() // Remove for release app
				.build();
		// Initialize ImageLoader with configuration.
		ImageLoader.getInstance().init(config);
	}

	// 生成Activity存入列表
	public static void addCurrentActivity(Activity activity) {
		mActivityList.add(activity);
	}

	// 获取当前Activity对象
	public Activity getCurrentActivity() {
		if (mActivityList.size() > 0) {
			return mActivityList.get(mActivityList.size() - 1);
		}
		return null;
	}

	// 清空Activity列表
	public static void clearActivityList() {
		for (int i = 0; i < mActivityList.size(); i++) {
			Activity activity = mActivityList.get(i);
			activity.finish();
		}
		mActivityList.clear();
	}

	// 退出程序处理
	public static void finish(Context context) {
		// DownloadManager downloadManager =
		// DownloadService.getDownloadManager(context);
		// try {
		// downloadManager.stopAllDownload();
		// downloadManager.backupDownloadInfoList();
		// } catch (DbException e) {
		// LogUtils.e(e.getMessage(), e);
		// }
		// 关闭程序退出的的Activity
		clearActivityList();

		// 退出
		// System.exit(0);
	}
}
