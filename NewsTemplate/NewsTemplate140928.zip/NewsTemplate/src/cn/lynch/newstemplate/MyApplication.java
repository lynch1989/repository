package cn.lynch.newstemplate;

import java.util.ArrayList;
import java.util.List;
import java.util.Stack;

import android.app.Activity;
import android.app.ActivityManager;
import android.content.Context;
import android.content.pm.PackageManager;
import android.os.Handler;
import android.os.Looper;

import com.baidu.frontia.FrontiaApplication;
import com.nostra13.universalimageloader.cache.disc.naming.Md5FileNameGenerator;
import com.nostra13.universalimageloader.core.ImageLoader;
import com.nostra13.universalimageloader.core.ImageLoaderConfiguration;
import com.nostra13.universalimageloader.core.assist.QueueProcessingType;

public class MyApplication extends FrontiaApplication {

	@SuppressWarnings("unused")
	private String TAG = MyApplication.class.getName();

	/**
	 * 全局Context，原理是因为Application类是应用最先运行的，所以在我们的代码调用时，该值已经被赋值过了
	 */
	private static MyApplication mApplication;
	/**
	 * 主线程ID
	 */
	private static int mMainThreadId = -1;
	/**
	 * 主线程
	 */
	private static Thread mMainThread;
	/**
	 * 主线程Handler
	 */
	private static Handler mMainThreadHandler;
	/**
	 * 主线程Looper
	 */
	private static Looper mMainLooper;
	/**
	 * 启动的Activity集合
	 */
	public static List<Activity> mActivityList = new ArrayList<Activity>();
	public static Stack<Activity> mActivityStack = new Stack<Activity>();;
	/**
	 * 上下文
	 */
	private Context mContext;
	/**
	 * 包管理器
	 */
	private PackageManager packageManager;

	public Context getContext() {
		return mContext;
	}

	public PackageManager getPM() {
		return packageManager;
	}

	@Override
	public void onCreate() {
		mMainThreadId = android.os.Process.myTid();
		mMainThread = Thread.currentThread();
		mMainThreadHandler = new Handler();
		mMainLooper = getMainLooper();
		mApplication = this;
		super.onCreate();

		mContext = getApplicationContext();
		packageManager = mContext.getPackageManager();
		initImageLoader(mContext);
//		initCaughtExceptionHandler();
	}

	@Override
	public void onTerminate() {
		super.onTerminate();
	}

	/**
	 * 初始化ImageLoader
	 */
	public static void initImageLoader(Context context) {
		// This configuration tuning is custom. You can tune every option, you
		// may tune some of them,
		// or you can create default configuration by
		// ImageLoaderConfiguration.createDefault(this);
		// method.
		ImageLoaderConfiguration config = new ImageLoaderConfiguration.Builder(
				context).threadPriority(Thread.NORM_PRIORITY - 2)
				.denyCacheImageMultipleSizesInMemory()
				.diskCacheFileNameGenerator(new Md5FileNameGenerator())
				.tasksProcessingOrder(QueueProcessingType.LIFO)
				.writeDebugLogs() // Remove for release app
				.build();
		// Initialize ImageLoader with configuration.
		ImageLoader.getInstance().init(config);
	}

	/**
	 * 初始化异常抓取Handler
	 */
	public void initCaughtExceptionHandler() {
		// 设置该CaughtExceptionHandler为程序的默认处理器
		MyCaughtExceptionHandler mCaughtExceptionHandler = new MyCaughtExceptionHandler(
				this);
		Thread.setDefaultUncaughtExceptionHandler(mCaughtExceptionHandler);
	}

	public static MyApplication getApplication() {
		return mApplication;
	}

	/**
	 * 获取主线程ID
	 */
	public static int getMainThreadId() {
		return mMainThreadId;
	}

	/**
	 * 获取主线程
	 */
	public static Thread getMainThread() {
		return mMainThread;
	}

	/**
	 * 获取主线程的handler
	 */
	public static Handler getMainThreadHandler() {
		return mMainThreadHandler;
	}

	/**
	 * 获取主线程的looper
	 */
	public static Looper getMainThreadLooper() {
		return mMainLooper;
	}

	/**
	 * 添加Activity到堆栈
	 */
	public void addActivity(Activity activity) {
		if (!mActivityStack.contains(activity)) {
			mActivityStack.add(activity);
		}
	}

	/**
	 * 获取当前Activity对象（堆栈中最后一个压入的）
	 */
	public Activity getCurrentActivity() {
		if (!mActivityStack.isEmpty()) {
			return mActivityStack.lastElement();
		}
		return null;
	}

	/**
	 * 返回到指定的Activity并且清除Stack中其位置之前（上）的所有Activity
	 * 
	 * @param clz
	 *            指定的Activity
	 * @return 该Activity
	 */
	public Activity getSingleTaskActivity(Class<?> clz) {
		Activity destActivity = null;
		if (null != clz) {
			int position = 0;
			if (null != mActivityStack && mActivityStack.size() > 0) {
				for (int i = 0; i < mActivityStack.size(); i++) {
					if (mActivityStack.get(i).getClass().getName()
							.contains(clz.getName())) {
						position = i;
					}
				}
				int num = mActivityStack.size() - position - 1;
				if (num > 0) {
					for (int i = 0; i < num; i++) {
						if (!mActivityStack.isEmpty()) {
							finishActivity(mActivityStack.pop());
						}
					}
				}
				destActivity = mActivityStack.pop();
			}
		}
		return destActivity;
	}

	/**
	 * 结束当前Activity（堆栈中最后一个压入的）
	 */
	public void finishActivity() {
		if (!mActivityStack.isEmpty()) {
			Activity activity = mActivityStack.lastElement();
			finishActivity(activity);
		}
	}

	/**
	 * 结束指定的Activity
	 */
	public void finishActivity(Activity activity) {
		if (activity != null) {
			mActivityStack.remove(activity);
			activity.finish();
			activity = null;
		}
	}

	/**
	 * 结束指定类名的Activity
	 */
	public void finishActivity(Class<?> cls) {
		for (Activity activity : mActivityStack) {
			if (activity.getClass().equals(cls)) {
				finishActivity(activity);
			}
		}
	}

	/**
	 * 结束所有Activity
	 */
	public void finishAllActivity() {
		for (int i = 0, size = mActivityStack.size(); i < size; i++) {
			if (null != mActivityStack.get(i)) {
				mActivityStack.get(i).finish();
			}
		}
		mActivityStack.clear();
	}

	/**
	 * 退出应用程序
	 */
	@SuppressWarnings("deprecation")
	public void exitApp() {
		try {
			finishAllActivity();
			ActivityManager mActivityManager = (ActivityManager) getApplication()
					.getSystemService(Context.ACTIVITY_SERVICE);
			mActivityManager.restartPackage(getApplication().getPackageName());
			System.exit(0);
		} catch (Exception e) {
			e.printStackTrace();
			System.exit(0);
		}
	}

}
