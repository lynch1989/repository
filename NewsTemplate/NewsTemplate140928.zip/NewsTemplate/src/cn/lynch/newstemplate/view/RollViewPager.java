package cn.lynch.newstemplate.view;

import java.util.List;

import android.annotation.SuppressLint;
import android.content.Context;
import android.graphics.Bitmap.Config;
import android.os.Handler;
import android.os.Message;
import android.support.v4.view.PagerAdapter;
import android.support.v4.view.ViewPager;
import android.util.AttributeSet;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import cn.lynch.newstemplate.R;
import cn.lynch.newstemplate.utils.AndroidUtils;
import cn.lynch.newstemplate.utils.LogUtils;

import com.lidroid.xutils.BitmapUtils;

public class RollViewPager extends ViewPager {
	
	private Context context;
	private List<View> dotLists;
	private int dotFocus;
	private int dotNormal;
	
	private TaskPager taskPager;
	private BitmapUtils bitmapUtils;
	
	private long startTimeMillis;

	public RollViewPager(Context context, AttributeSet attrs) {
		super(context, attrs);
	}

	public RollViewPager(Context context) {
		super(context);
	}
	
	public RollViewPager(Context context, List<View> dotLists, int dotFocus,
			int dotNormal, OnPagerClickCallBack onPagerClickCallBack) {
		super(context);
		this.context = context;
		this.dotLists = dotLists;
		this.dotFocus = dotFocus;
		this.dotNormal = dotNormal;
		this.onPagerClickCallBack = onPagerClickCallBack;
		
		bitmapUtils = new BitmapUtils(context);
		bitmapUtils.configDefaultBitmapConfig(Config.RGB_565);
		taskPager = new TaskPager();
		myTouchListener = new MyTouchListener();
	}
	
	public class MyTouchListener implements OnTouchListener {

		@SuppressWarnings("unused")
		@Override
		public boolean onTouch(View v, MotionEvent event) {
			float curX = event.getX();
			float curY = event.getY();
			switch (event.getAction()) {
			case MotionEvent.ACTION_DOWN:
				startTimeMillis = System.currentTimeMillis();
				handler.removeCallbacksAndMessages(null);
				break;
			case MotionEvent.ACTION_MOVE:
				handler.removeCallbacks(taskPager);
				break;
			case MotionEvent.ACTION_CANCEL:
				startRoll();
				break;
			case MotionEvent.ACTION_UP:
				/**
				 * 1 当用户在ACTION_DOWN的时候，记录一下点击的时间
				 * 2 当用户在ACTION_UP的时候，再记录一下用户抬起的时间
				 * 3 若两个值的差小于500，且curX和抬起时X轴的值相等的话，判断是点击事件
				 */
				long duration = System.currentTimeMillis() - startTimeMillis;
				if (duration < 500 && event.getX() == curX) {
					onPagerClickCallBack.pagerClickCallBack(currentPosition);
				}
				startRoll();
				break;
			}
			return true;
		}
	}
	
	public interface OnPagerClickCallBack {
		public void pagerClickCallBack(int position);
	}
	
	private OnPagerClickCallBack onPagerClickCallBack;
	
	@Override
	public boolean dispatchTouchEvent(MotionEvent ev) {
		switch (ev.getAction()) {
		case MotionEvent.ACTION_DOWN:
			downX = ev.getX();
			downY = ev.getY();
//			requestDisallowInterceptTouchEvent(true);
			getParent().requestDisallowInterceptTouchEvent(true);
			break;
		case MotionEvent.ACTION_MOVE:
			float moveX = ev.getX();
			float moveY = ev.getY();
			/**
			 * 当X轴的位移大于Y轴的位移时响应的是ViewPager的事件
			 * 当Y轴的位置大于X轴的位移时响应的是ListView的事件
			 */
			if(Math.abs(downX-moveX) > Math.abs(downY-moveY)){
				LogUtils.d("ViewPager----------");
//				requestDisallowInterceptTouchEvent(true);
				getParent().requestDisallowInterceptTouchEvent(true);
			}else{
				LogUtils.d("ListView----------");
//				requestDisallowInterceptTouchEvent(false);
				getParent().requestDisallowInterceptTouchEvent(false);
			}
			break;
		case MotionEvent.ACTION_UP:
			break;
		case MotionEvent.ACTION_CANCEL:
			getParent().requestDisallowInterceptTouchEvent(false);
			break;
		}
		return super.dispatchTouchEvent(ev);
	}

	private List<String> imageUrlLists;
	public void setImageUrlList(List<String> imageUrlLists) {
		this.imageUrlLists = imageUrlLists;
	}

	private List<String> titleLists;
	private TextView top_news_title;
	
	public void setTitleList(List<String> titleLists, TextView top_news_title) {
		this.titleLists = titleLists;
		this.top_news_title = top_news_title;
		if(this.titleLists != null && this.titleLists.size() > 0){
			top_news_title.setText(titleLists.get(0));
		}
	}

	private boolean hasPagerAdapter = false;
	public void startRoll() {
		handler.removeCallbacksAndMessages(null);
		if(!hasPagerAdapter){
			hasPagerAdapter = true;
			RollViewPager.this.setOnPageChangeListener(new MyOnPageChangeListener());
			ViewPagerAdapter viewPagerAdapter = new ViewPagerAdapter();
			this.setAdapter(viewPagerAdapter);
		}
		handler.postDelayed(taskPager, 4000);
	}

	private int currentPosition = 0;
	public class MyOnPageChangeListener implements OnPageChangeListener{
		
		int oldPosition = 0;
		
		@Override
		public void onPageSelected(int position) {
			currentPosition = position;
			if(dotLists != null && dotLists.size() > 0){
				dotLists.get(position).setBackgroundResource(dotFocus);
				dotLists.get(oldPosition).setBackgroundResource(dotNormal);
			}
			if(titleLists != null && titleLists.size() > 0){
				top_news_title.setText(titleLists.get(position));
			}
			oldPosition = currentPosition;
		}

		@Override
		public void onPageScrollStateChanged(int arg0) {
			
		}

		@Override
		public void onPageScrolled(int arg0, float arg1, int arg2) {
			
		}
	}
	
	public class TaskPager implements Runnable{

		@Override
		public void run() {
			currentPosition = (currentPosition + 1) % imageUrlLists.size();
			handler.obtainMessage().sendToTarget();
		}
	}
	
	@SuppressLint("HandlerLeak")
	public Handler handler = new Handler(){
		@Override
		public void handleMessage(Message msg) {
			super.handleMessage(msg);
			LogUtils.i("RollViewPager----"+currentPosition+"---"+AndroidUtils.getCurrentTime());
			RollViewPager.this.setCurrentItem(currentPosition);
			startRoll();
		}
	};
	private float downX;
	private float downY;
	private MyTouchListener myTouchListener;
	
	public class ViewPagerAdapter extends PagerAdapter{

		@Override
		public void destroyItem(ViewGroup container, int position, Object object) {
			((ViewPager)container).removeView((View)object);
		}

		@Override
		public Object instantiateItem(ViewGroup container, int position) {
			View view = View.inflate(context, R.layout.viewpager_item, null);
			ImageView iv = (ImageView) view.findViewById(R.id.iv_image);
			bitmapUtils.display(iv, imageUrlLists.get(position));
			((ViewPager)container).addView(view);
			view.setOnTouchListener(myTouchListener);
			return view;
		}

		@Override
		public int getCount() {
			return imageUrlLists.size();
		}

		@Override
		public boolean isViewFromObject(View arg0, Object arg1) {
			return arg0 == arg1;
		}
	}
	
	@Override
	protected void onDetachedFromWindow() {
		handler.removeCallbacksAndMessages(null);
		super.onDetachedFromWindow();
	}
}
