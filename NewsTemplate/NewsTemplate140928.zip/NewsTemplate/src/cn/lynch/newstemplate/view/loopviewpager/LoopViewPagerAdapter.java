package cn.lynch.newstemplate.view.loopviewpager;

import java.util.Collections;
import java.util.LinkedList;
import java.util.List;

import android.content.Context;
import android.graphics.Bitmap;
import android.support.v4.view.PagerAdapter;
import android.support.v4.view.ViewPager;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;

import com.nostra13.universalimageloader.core.DisplayImageOptions;
import com.nostra13.universalimageloader.core.ImageLoader;
import com.nostra13.universalimageloader.core.display.FadeInBitmapDisplayer;
import com.nostra13.universalimageloader.core.display.SimpleBitmapDisplayer;
import com.nostra13.universalimageloader.core.listener.ImageLoadingListener;
import com.nostra13.universalimageloader.core.listener.SimpleImageLoadingListener;

public abstract class LoopViewPagerAdapter<T> extends PagerAdapter {

	protected List<T> mList;
	protected LayoutInflater inflater;
	protected Context mContext;
	protected ImageLoader imageLoader = ImageLoader.getInstance();
	protected DisplayImageOptions options;
	protected ImageLoadingListener animateFirstListener = new AnimateFirstDisplayListener();

	public LoopViewPagerAdapter(Context mContext, List<T> mList, int loadingImage, int emptyImage, int failImage) {
		this.mList = mList;
		this.mContext = mContext;
		inflater = LayoutInflater.from(mContext);
		options = new DisplayImageOptions.Builder()
				.showImageOnLoading(loadingImage)
				.showImageForEmptyUri(emptyImage)
				.showImageOnFail(failImage)
				.cacheInMemory(true)
				.cacheOnDisk(true)
				.considerExifParams(true)
				.displayer(new SimpleBitmapDisplayer())
				.build();
	}

	@Override
	public void destroyItem(ViewGroup container, int position, Object object) {
		((ViewPager) container).removeView((View) object);
	}

	@Override
	public abstract Object instantiateItem(ViewGroup container, final int position);

	@Override
	public int getCount() {
		return mList == null ? 0 : mList.size();
	}

	@Override
	public boolean isViewFromObject(View arg0, Object arg1) {
		return arg0 == arg1;
	}
	
	protected void displayImageByImageLoader(String url, ImageView imageView) {
		imageLoader.displayImage(url, imageView, options, animateFirstListener);
	}

	private static class AnimateFirstDisplayListener extends
			SimpleImageLoadingListener {

		static final List<String> displayedImages = Collections
				.synchronizedList(new LinkedList<String>());

		@Override
		public void onLoadingComplete(String imageUri, View view,
				Bitmap loadedImage) {
			if (loadedImage != null) {
				ImageView imageView = (ImageView) view;
				boolean firstDisplay = !displayedImages.contains(imageUri);
				if (firstDisplay) {
					FadeInBitmapDisplayer.animate(imageView, 500);
					displayedImages.add(imageUri);
				}
			}
		}
	}
}
