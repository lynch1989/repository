package cn.lynch.newstemplate.view;

import android.content.Context;
import android.util.AttributeSet;
import android.view.MotionEvent;

public class CustomViewPager extends LazyViewPager {

	public boolean hasSetTouchMode = false;
	
	public CustomViewPager(Context context, AttributeSet attrs) {
		super(context, attrs);
	}

	public CustomViewPager(Context context) {
		super(context);
	}
	
//	@Override
//	public boolean dispatchTouchEvent(MotionEvent ev) {
//		return false;
//	}
	
	@Override
	public boolean onInterceptTouchEvent(MotionEvent ev) {
		if (hasSetTouchMode)
			return super.onInterceptTouchEvent(ev);
		else
			return false;
	}
	
	@Override
	public boolean onTouchEvent(MotionEvent ev) {
		//false	事件往下分发
		//true  把事件消费掉
		if (hasSetTouchMode)
			return super.onTouchEvent(ev);
		else
			return false;
	}
	
}
