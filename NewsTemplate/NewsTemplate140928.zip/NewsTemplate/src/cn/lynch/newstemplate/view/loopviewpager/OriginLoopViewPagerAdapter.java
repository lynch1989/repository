package cn.lynch.newstemplate.view.loopviewpager;

import java.util.Collections;
import java.util.LinkedList;
import java.util.List;

import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.net.Uri;
import android.support.v4.view.PagerAdapter;
import android.support.v4.view.ViewPager;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.ImageView;
import cn.lynch.newstemplate.R;
import cn.lynch.newstemplate.activity.NewsDetailActivity;
import cn.lynch.newstemplate.bean.ViewPagerImage;

import com.nostra13.universalimageloader.core.DisplayImageOptions;
import com.nostra13.universalimageloader.core.ImageLoader;
import com.nostra13.universalimageloader.core.display.FadeInBitmapDisplayer;
import com.nostra13.universalimageloader.core.display.SimpleBitmapDisplayer;
import com.nostra13.universalimageloader.core.listener.ImageLoadingListener;
import com.nostra13.universalimageloader.core.listener.SimpleImageLoadingListener;

/**
 * 抽取成LoopViewPagerAdapter和HeadlinesLoopViewPagerAdapter
 */
public class OriginLoopViewPagerAdapter extends PagerAdapter {

	private List<ViewPagerImage> mList;
	private LayoutInflater inflater;
	private Context mContext;
	private ImageLoader imageLoader = ImageLoader.getInstance();
	private DisplayImageOptions options;
	private ImageLoadingListener animateFirstListener = new AnimateFirstDisplayListener();

	public OriginLoopViewPagerAdapter(List<ViewPagerImage> mList, Context mContext) {
		this.mList = mList;
		this.mContext = mContext;
		inflater = LayoutInflater.from(mContext);
		options = new DisplayImageOptions.Builder()
				.showImageOnLoading(R.drawable.banner_default)
				.showImageForEmptyUri(R.drawable.banner_default)
				.showImageOnFail(R.drawable.banner_default)
				.cacheInMemory(true)
				.cacheOnDisk(true)
				.considerExifParams(true)
				.displayer(new SimpleBitmapDisplayer())
				.build();
	}

	@Override
	public void destroyItem(ViewGroup container, int position, Object object) {
		((ViewPager) container).removeView((View) object);
	}

	@Override
	public Object instantiateItem(ViewGroup container, final int position) {
		final View itemView = inflater.inflate(R.layout.loopviewpager_item, null);
		
		final ImageView imageView = (ImageView) itemView.findViewById(R.id.loopviewpager_image);
		imageView.setTag(position);
		imageView.setBackgroundResource(R.drawable.banner_default);
		String url = mList.get(position).getImage_url();
		
		imageLoader.displayImage(url, imageView, options, animateFirstListener);
		
		final ViewPagerImage viewPagerImage = mList.get(position);
		imageView.setOnClickListener(new OnClickListener() {
			Intent intent;

			@Override
			public void onClick(View v) {
				String type = viewPagerImage.getType();
				if ("app".equals(type)) {
					intent = new Intent(mContext, NewsDetailActivity.class);
					intent.putExtra("id", Integer.valueOf(viewPagerImage.getLink()));
				} else if ("web".equals(type)) {
					String url = viewPagerImage.getLink();
					intent = new Intent(Intent.ACTION_VIEW);
					if (url.startsWith("www")) {
						url = "http://" + url;
					}
					intent.setData(Uri.parse(url));
				} else if ("activity".equals(type)) {
					intent = new Intent(mContext, NewsDetailActivity.class);
					intent.putExtra("activity_id", viewPagerImage.getLink());
				}
				mContext.startActivity(intent);
			}
		});
		container.addView(itemView, 0);
		return itemView;
	}

	@Override
	public int getCount() {
		return mList == null ? 0 : mList.size();
	}

	@Override
	public boolean isViewFromObject(View arg0, Object arg1) {
		return arg0 == arg1;
	}

	private static class AnimateFirstDisplayListener extends
			SimpleImageLoadingListener {

		static final List<String> displayedImages = Collections
				.synchronizedList(new LinkedList<String>());

		@Override
		public void onLoadingComplete(String imageUri, View view,
				Bitmap loadedImage) {
			if (loadedImage != null) {
				ImageView imageView = (ImageView) view;
				boolean firstDisplay = !displayedImages.contains(imageUri);
				if (firstDisplay) {
					FadeInBitmapDisplayer.animate(imageView, 500);
					displayedImages.add(imageUri);
				}
			}
		}
	}
}
