package cn.lynch.newstemplate.network.protocol.base;

import cn.lynch.newstemplate.network.HttpHelper;
import cn.lynch.newstemplate.network.HttpHelper.HttpResult;
import cn.lynch.newstemplate.utils.LogUtils;


public abstract class BasePostProtocol<T> extends BaseProtocol<T> {

	@Override
	protected String loadFromNet() {
		String result = null;
		byte[] bytes = new byte[1024];
		HttpResult httpResult = HttpHelper.post(HttpHelper.URL + getKey()
				+ getParames(), bytes);
		LogUtils.i("post请求url： " + HttpHelper.URL + "   请求key： " + getKey()
				+ "   请求参数： " + getParames());
		if (httpResult != null) {
			result = httpResult.getString();
			httpResult.close();
		}
		return result;
	}
}
