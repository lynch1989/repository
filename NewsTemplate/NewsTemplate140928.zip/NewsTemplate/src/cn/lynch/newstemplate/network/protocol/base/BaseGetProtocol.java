package cn.lynch.newstemplate.network.protocol.base;

import cn.lynch.newstemplate.network.HttpHelper;
import cn.lynch.newstemplate.network.HttpHelper.HttpResult;
import cn.lynch.newstemplate.utils.LogUtils;

public abstract class BaseGetProtocol<T> extends BaseProtocol<T> {

	/**
	 * 使用GET请求从网络加载协议
	 */	
	@Override
	protected String loadFromNet() {
		String result = null;
		HttpResult httpResult = HttpHelper.get(HttpHelper.URL + getKey()
				+ getParames());
		LogUtils.i("get请求url： " + HttpHelper.URL + "   请求key： " + getKey()
				+ "   请求参数： " + getParames());
		if (httpResult != null) {
			result = httpResult.getString();
			httpResult.close();
		}
		return result;
	}
}
