package cn.lynch.newstemplate.network.protocol;

import java.util.HashMap;

import org.json.JSONException;
import org.json.JSONObject;

import cn.lynch.newstemplate.bean.User;
import cn.lynch.newstemplate.network.protocol.base.BaseGetProtocol;
import cn.lynch.newstemplate.utils.LogUtils;
import cn.lynch.newstemplate.utils.URLUtils;

public class RegisterProtocol extends BaseGetProtocol<User> {

	private String loginName;
	private String password;

	public RegisterProtocol(String loginName,String password) {
		this.loginName = loginName;
		this.password = password;
	}

	@Override
	protected String getKey() {
		return URLUtils.REGISTER_URL;
	}

	@Override
	protected User parseFromJson(String json) {
		try {
			JSONObject obj = new JSONObject(json);
			LogUtils.i("注册json : "+json);
			User user = new User();
			user.setLoginName(loginName);
			user.setPassword(password);;
			user.setStatus(obj.getBoolean("status"));
			user.setToken(obj.getString("token"));
			user.setMessage(obj.getString("message"));
			LogUtils.i("注册 user 信息: "+user.toString());
			return user;
		} catch (JSONException e) {
			e.printStackTrace();
		}
		return null;
	}

	@Override
	protected String getParames() {
		HashMap<String, String> params = new HashMap<String, String>();
		StringBuffer queryString = null;
		params.put("platform", "0");
		params.put("username", loginName);
		params.put("password", password);
		if (params != null && params.size() > 0) {
			queryString = new StringBuffer("?");
			queryString = joinParam(params, queryString);
		}
		return queryString.toString();
	}
}
