package cn.lynch.newstemplate.activity;

import java.util.HashMap;

import android.app.Activity;
import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.SystemClock;
import android.util.Log;
import android.view.animation.AlphaAnimation;
import android.view.animation.Animation;
import android.view.animation.Animation.AnimationListener;
import android.widget.ImageView;
import cn.lynch.newstemplate.MyApplication;
import cn.lynch.newstemplate.R;
import cn.lynch.newstemplate.network.NativeHttp;
import cn.lynch.newstemplate.utils.AndroidUtils;
import cn.lynch.newstemplate.utils.LogUtils;
import cn.lynch.newstemplate.utils.PushUtils;
import cn.lynch.newstemplate.utils.UIUtils;
import cn.lynch.newstemplate.utils.URLUtils;

import com.baidu.android.pushservice.PushConstants;
import com.baidu.android.pushservice.PushManager;

public class SplashActivity extends Activity {

	private String appid;
	private String userId;
	private String channelId;
	private String activityId;
	
	private MyApplication app;
	
	@SuppressWarnings("static-access")
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_splash);
		
		app = (MyApplication) getApplication();
		
		app.addActivity(this);
		if (!AndroidUtils.isNetworkConnected(SplashActivity.this)) {
			UIUtils.showShortSafeToast("网络不可用，请稍后再试");
			app.finishActivity(this);
			return;
		}

		ImageView splash = (ImageView) findViewById(R.id.splash_image);
		AlphaAnimation alphaAnimation = new AlphaAnimation(0.5f, 1.0f);
		alphaAnimation.setDuration(2000);
		splash.startAnimation(alphaAnimation);

		alphaAnimation.setAnimationListener(new AnimationListener() {
			
			@Override
			public void onAnimationStart(Animation animation) {
			}
			
			@Override
			public void onAnimationRepeat(Animation animation) {
			}
			
			@Override
			public void onAnimationEnd(Animation animation) {
				// 上传消息推送参数
				if (!PushUtils.hasBind(getApplicationContext())) {
					PushManager.startWork(getApplicationContext(),
							PushConstants.LOGIN_TYPE_API_KEY,
							PushUtils.getMetaValue(SplashActivity.this, "api_key"));
				}

				appid = getIntent().getStringExtra("appid");
				userId = getIntent().getStringExtra("userId");
				channelId = getIntent().getStringExtra("channelId");
				LogUtils.i("获取的推送信息 ：appid = " + appid + "  userId = " + userId + "  channelId = " + channelId);
				if (appid != null && userId != null && channelId != null) {
					new AsyncTask<Void, Void, String>() {
						private NativeHttp httpUtil;
						@Override
						protected String doInBackground(Void... params) {
							SystemClock.sleep(500);
							httpUtil = new NativeHttp();
							HashMap<String, String> map = new HashMap<String, String>();
							map.put("platform", "0");
							map.put("push_app_id", appid);
							map.put("push_user_id", userId);
							map.put("push_channel_id", channelId);
							LogUtils.i("请求参数：appid = " + appid + "  userId = " + userId + "  channelId = " + channelId);
							String json = httpUtil.post(URLUtils.IP_URL + URLUtils.PUSH_URL, map);
							Log.i("TAG", "消息推送  : " + json);
							return "消息推送上传信息";
						}
						protected void onPostExecute(String result) {
						};
					}.execute();
				}
				
				// 推送打开应用的操作
				activityId = getIntent().getStringExtra("activity_id");
				LogUtils.i("splash activity_id = " + activityId);
				final Intent intent;
				if (activityId == null) {
					intent = new Intent(SplashActivity.this, HomeActivity.class);
				} else {
					intent = new Intent(SplashActivity.this, HomeActivity.class);
					intent.putExtra("activity_id", activityId);
				}
				app.getMainThreadHandler().post(new Runnable() {
					@Override
					public void run() {
						SystemClock.sleep(2000);
						startActivity(intent);
						finish();
					}
				});
			}
		});
	}
}
