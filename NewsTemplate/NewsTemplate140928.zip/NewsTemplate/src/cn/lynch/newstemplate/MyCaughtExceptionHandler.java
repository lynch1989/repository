package cn.lynch.newstemplate;

import java.lang.Thread.UncaughtExceptionHandler;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.os.Looper;
import android.util.Log;
import cn.lynch.newstemplate.activity.HomeActivity;
import cn.lynch.newstemplate.utils.AndroidUtils;
import cn.lynch.newstemplate.utils.LogUtils;
import cn.lynch.newstemplate.utils.UIUtils;

public class MyCaughtExceptionHandler implements UncaughtExceptionHandler {

	private static final String TAG = MyCaughtExceptionHandler.class.getName();
	private static final long SLEEP_TIME = 2000;
	
	/**
	 * 系统默认的UncaughtException处理类
	 */
	private Thread.UncaughtExceptionHandler mDefaultHandler;    
    private Context mContext;
	
	public MyCaughtExceptionHandler(Context context) {
		this.mContext = context;
		// 获取系统默认的UncaughtException处理器
		mDefaultHandler = Thread.getDefaultUncaughtExceptionHandler();
		// 设置该CrashHandler为程序的默认处理器
		Thread.setDefaultUncaughtExceptionHandler(this);
	}

	@Override
	public void uncaughtException(Thread thread, Throwable ex) {
		if(!handleException(ex) && mDefaultHandler != null){   
            //如果用户没有处理则让系统默认的异常处理器来处理    
            mDefaultHandler.uncaughtException(thread, ex);                
        }else{
            try{    
                Thread.sleep(SLEEP_TIME);    
            }catch (InterruptedException e){
                Log.e(TAG, "error : ", e);    
            }     
            Intent intent = new Intent(mContext, HomeActivity.class);  
			PendingIntent restartIntent = PendingIntent.getActivity(mContext, 0, intent, Intent.FLAG_ACTIVITY_NEW_TASK);                                              
            //退出程序                                          
			AlarmManager mgr = (AlarmManager) mContext.getSystemService(Context.ALARM_SERVICE);    
			// 1秒钟后重启应用  
			mgr.set(AlarmManager.RTC, System.currentTimeMillis() + 1000, restartIntent);
			MyApplication.getApplication().exitApp();
        }    
		
	}
	
	/**  
     * 自定义错误处理,收集错误信息 发送错误报告等操作均在此完成.  
     *   
     * @param ex  
     * @return 如果处理了该异常信息返回true;否则返回false.  
     */    
    private boolean handleException(Throwable ex) {    
		if (ex == null) {
			return false;
		}
		
		ex.printStackTrace();
		final String crashMessage = createCrashMessage(ex);
		LogUtils.e(crashMessage);
		
        //使用Toast来显示异常信息    
        new Thread(){    
            @Override    
            public void run() {    
				Looper.prepare();
				UIUtils.showShortSafeToast("很抱歉,出现异常即将退出,稍后会重启！");
				
				String path = ConstantValues.SAVE_PATH + "/" + AndroidUtils.getCurrentTime("yyyyMMdd") + ".txt";
//				String path = FileUtils.getDiskCachePath(mContext) + "/" + AndroidUtils.getCurrentTime("yyyyMMdd") + ".txt";
				LogUtils.log2File(crashMessage, path);
				
				Looper.loop();
            }   
        }.start();    
        return true;    
    }    

	private String createCrashMessage(Throwable ex) {
		StringBuilder buffer = new StringBuilder();
		buffer.append(getCrashInfo(ex));
		Throwable cause = ex.getCause();
		while (cause != null) {
			buffer.append(getCrashInfo(cause));
			cause = cause.getCause();
		}
		return buffer.toString();
	}

	private String getCrashInfo(Throwable cause) {
		if (cause == null) {
			return "";
		}
		StringBuilder buffer = new StringBuilder();
		buffer.append("[" + AndroidUtils.getCurrentTime() + "] ");
		buffer.append("程序异常").append(" : ").append(cause.getClass().getName())
				.append(": ").append(cause.getLocalizedMessage()).append("\n");
		StackTraceElement[] t = cause.getStackTrace();
		for (StackTraceElement ste : t) {
			buffer.append("\tat: ").append(ste.getClassName()).append(".")
					.append(ste.getMethodName()).append("(")
					.append(ste.getFileName()).append(":")
					.append(ste.getLineNumber()).append(")\n");
		}
		return buffer.toString();
	}
}
