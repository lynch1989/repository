package cn.lynch.newstemplate.bean;

public class News {

	private String title;
	private String imageUrl;
	
	public News() {
		super();
	}
	
	public News(String title, String imageUrl) {
		super();
		this.title = title;
		this.imageUrl = imageUrl;
	}

	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public String getImageUrl() {
		return imageUrl;
	}
	public void setImageUrl(String imageUrl) {
		this.imageUrl = imageUrl;
	}

	@Override
	public String toString() {
		return "News [title=" + title + ", imageUrl=" + imageUrl + "]";
	}
}
