package cn.lynch.newstemplate.bean;

import java.io.Serializable;

/**
 * 轮转图
 */
public class ViewPagerImage implements Serializable {

	private static final long serialVersionUID = 6423110100032924926L;

	private String image_url;
	private String type;
	private String link;

	public String getImage_url() {
		return image_url;
	}

	public void setImage_url(String image_url) {
		this.image_url = image_url;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public String getLink() {
		return link;
	}

	public void setLink(String link) {
		this.link = link;
	}

	@Override
	public String toString() {
		return "Recommend [image_url=" + image_url + ", type=" + type
				+ ", link=" + link + "]";
	}
}
