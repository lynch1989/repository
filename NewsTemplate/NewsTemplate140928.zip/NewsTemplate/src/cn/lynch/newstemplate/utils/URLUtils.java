package cn.lynch.newstemplate.utils;

public class URLUtils {
	
	public static final int TIME_OUT = 5000;
	/** ip地址 */
	public static final String IP_URL = "http://115.29.137.127:8082";
	/** 注册URL */
	public static final String REGISTER_URL ="/UsersApi/register.json";
	/** 登录URL */
	public static final String LOGIN_URL ="/UsersApi/login.json";
	/** 验证token是否过期URL */
	public static final String TOKEN_URL ="/UsersApi/tokenexpires.json";
	/** 验证ptoken是否过期URL */
	public static final String PTOKEN_URL ="/UsersApi/ptokenexpires.json";
	/** 大轮转位URL */
	public static final String RECOMMEND_URL ="/RecommendsApi/getlist.json";
	/** 分类列表URL */
	public static final String CATAGORY_URL ="/AppApi/getallcategorys.json";
	/** 根据类型获取分类列表URL */
	public static final String GETCATEGORYS_LIST_URL ="/AppApi/getcategorys.json";
	/** 首页应用URL 暂时不用，ios使用*/
	public static final String HOMELIST_URL ="/AppApi/gethomelist.json";
	/** 应用列表URL */
	public static final String LIST_URL = "/AppApi/getlist.json";
	/** 应用详情URL */
	public static final String INFO_URL =IP_URL +  "/AppApi/getinfo.json";
	/** 应用更新URL */
	public static final String GETUPDATE_URL ="/AppApi/getupdatelist.json";
	/** 应用排行URL */
	public static final String RANKING_URL ="/AppApi/rank.json";
	/** 评论列表URL */
	public static final String COMMENTLIST_URL ="/CommentApi/getlist.json";
	/** 发表评论URL */
	public static final String COMMENT_URL ="/CommentApi/create.json";
	/** 活动列表URL */
	public static final String ACTIVITY_LIST_URL ="/ActivitiesApi/getlist.json";
	/** 活动详情URL */
	public static final String ACTIVITY_INFO_URL ="/ActivitiesApi/getinfo.json";
	/** 活动参与URL */
	public static final String ACTIVITY_JOIN_URL ="/ActivitiesApi/joins.json";
	/** 反馈类型URL */
	public static final String FEEDBACK_CATAGORY_URL ="/IdeasApi/getcategorys.json";
	/** 发送反馈URL */
	public static final String FEEDBACK_URL ="/IdeasApi/create.json";
	/** 消息推送URL */
	public static final String PUSH_URL ="/MobilePushApi/binduser.json";
}
