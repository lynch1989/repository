package cn.lynch.newstemplate.utils;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;

import android.content.Context;

import cn.lynch.newstemplate.ConstantValues;

import com.lidroid.xutils.HttpUtils;
import com.lidroid.xutils.exception.HttpException;
import com.lidroid.xutils.http.RequestParams;
import com.lidroid.xutils.http.ResponseStream;
import com.lidroid.xutils.http.client.HttpRequest.HttpMethod;

public class NetDataUtils {

	public static String sendPost(RequestParams requestParams, String contextUrl) {
		String result = "";
		HttpUtils httpUtils = new HttpUtils();
		httpUtils.configResponseTextCharset("UTF-8");
		try {
			ResponseStream response = httpUtils.sendSync(HttpMethod.POST,
					ConstantValues.url + contextUrl, requestParams);
			String responseStr = response.readString();
			return responseStr;
		} catch (HttpException e) {
			e.printStackTrace();
			LogUtils.e(e.toString());
		} catch (IOException e) {
			e.printStackTrace();
			LogUtils.e(e.toString());
		}
		return result;
	}

	// "/AppApi/getinfo.json"
	public static String sendGet(RequestParams requestParams, String contextUrl) {
		HttpUtils httpUtils = new HttpUtils();
		httpUtils.configResponseTextCharset("UTF-8");
		try {
			ResponseStream response = httpUtils.sendSync(HttpMethod.GET,
					ConstantValues.url + contextUrl, requestParams);
			String responseStr = response.readString();
			return responseStr;
		} catch (HttpException e) {
			e.printStackTrace();
			LogUtils.e(e.toString());
		} catch (IOException e) {
			e.printStackTrace();
			LogUtils.e(e.toString());
		}
		return null;
	}

	public static String loadFromLocal(Context context, String fileName) {
		File path = context.getCacheDir();
		BufferedReader reader = null;
		try {
			// 读取缓存时间
			reader = new BufferedReader(new FileReader(path.getAbsolutePath()
					+ "/" + fileName));
			String line = reader.readLine();
			Long time = Long.valueOf(line);
			// 如果有网 并且超过了缓存时间，返回null
			if (AndroidUtils.isNetworkConnected(context)
					&& time < System.currentTimeMillis()) {
				return null;
			} else {
				StringBuilder sb = new StringBuilder();
				String result;
				while ((result = reader.readLine()) != null) {
					sb.append(result);
				}
				return sb.toString();
			}
		} catch (Exception e) {
			e.printStackTrace();
			LogUtils.e(e.toString());
		} finally {
			try {
				if (reader != null) {
					reader.close();
					reader = null;
				}
			} catch (Exception e) {
				e.printStackTrace();
				LogUtils.e(e.toString());
			}
		}
		return null;
	}

	public static void saveToLocal(Context context, String cacheContent,
			String fileName) {
		File path = context.getCacheDir();
		BufferedWriter writer = null;
		try {
			writer = new BufferedWriter(new FileWriter(path.getAbsolutePath()
					+ "/" + fileName));
			long time = System.currentTimeMillis() + 1000 * 40;
			writer.write(time + "\r\n");
			writer.write(cacheContent.toCharArray());
			writer.flush();
		} catch (Exception e) {
			e.printStackTrace();
			LogUtils.e(e.toString());
		} finally {
			try {
				if (writer != null) {
					writer.close();
					writer = null;
				}
			} catch (Exception e) {
				e.printStackTrace();
				LogUtils.e(e.toString());
			}
		}
	}
}
