package cn.lynch.newstemplate.utils;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;

import android.app.ActivityManager;
import android.content.Context;
import android.os.Environment;
import android.os.Looper;
import android.util.Log;
import android.widget.Toast;
import cn.lynch.newstemplate.MyApplication;

public class CrashHandler implements Thread.UncaughtExceptionHandler {

	// private Logger mLogger = Logger.createLogger("CrashHandler");

	// 系统默认的UncaughtException处理类
	private Thread.UncaughtExceptionHandler mDefaultHandler;

	private static MyApplication sApp;
	private Context mContext;

	public CrashHandler(Context context) {
		try {
			if (sApp == null) {
				sApp = (MyApplication) context;
			}
		} catch (Exception e) {
		}
		mContext = context;
		init();
	}

	private void init() {
		// 获取系统默认的UncaughtException处理器
		mDefaultHandler = Thread.getDefaultUncaughtExceptionHandler();
		// 设置该CrashHandler为程序的默认处理器
		Thread.setDefaultUncaughtExceptionHandler(this);
	}

	/**
	 * 当UncaughtException发生时会转入该函数来处理
	 */
	@Override
	public void uncaughtException(Thread thread, Throwable ex) {
		if (mDefaultHandler != null && !handleException(ex)) {
			// 如果用户没有处理则让系统默认的异常处理器来处理
			mDefaultHandler.uncaughtException(thread, ex);
		} else {
			try {
				Thread.sleep(3000);
			} catch (InterruptedException e) {
				 Log.e("TAG","error : " + e);
			}
		}
	}

	private boolean handleException(final Throwable ex) {
		if (ex == null) {
			return false;
		}
		ex.printStackTrace();
		final String crash = createCrashMessage(ex);
		 Log.e("TAG","crash error : " + crash);
		 if (mContext != null) {
				Toast.makeText(mContext, "程序异常退出，请重新启动", Toast.LENGTH_SHORT)
						.show();
				try {
					Thread.sleep(3000);
				} catch (InterruptedException e) {
					 Log.e("TAG","error : " + e);
				}
			}
		new Thread() {
			@SuppressWarnings({ "deprecation", "static-access" })
			@Override
			public void run() {
				Looper.prepare();
				
//				String path = Environment.getExternalStorageDirectory().getAbsolutePath() + "/newstemplate/";
				String path = FileUtils.getCacheDir() + "/newstemplate/";
				File file = new File(path, "exception.txt");
				if(!file.exists()){
					try {
						file.createNewFile();
					} catch (IOException e) {
						e.printStackTrace();
					}
				}
				try {
					FileOutputStream fos = new FileOutputStream(file, true);
					fos.write(crash.getBytes());
					fos.close();
				} catch (IOException e) {
					e.printStackTrace();
				}
				// 退出程序
				if (sApp != null) {
					sApp.exitApp();
				}
				ActivityManager activityMgr = (ActivityManager) mContext
						.getSystemService(Context.ACTIVITY_SERVICE);
				activityMgr.restartPackage(mContext.getPackageName());
				Looper.loop();
			}
		}.start();
		return true;
	}

	private String createCrashMessage(Throwable ex) {
		StringBuilder buffer = new StringBuilder();
		buffer.append(getCrashInfo(ex));
		Throwable cause = ex.getCause();
		while (cause != null) {
			buffer.append(getCrashInfo(cause));
			cause = cause.getCause();
		}
		return buffer.toString();
	}

	private String getCrashInfo(Throwable cause) {
		if (cause == null) {
			return "";
		}
		StringBuilder buffer = new StringBuilder();
		buffer.append("程序异常").append(" : ").append(cause.getClass().getName())
				.append(": ").append(cause.getLocalizedMessage()).append("\n");
		StackTraceElement[] t = cause.getStackTrace();
		for (StackTraceElement ste : t) {
			buffer.append("\tat: ").append(ste.getClassName()).append(".")
					.append(ste.getMethodName()).append("(")
					.append(ste.getFileName()).append(":")
					.append(ste.getLineNumber()).append(")\n");
		}
		return buffer.toString();
	}
}
