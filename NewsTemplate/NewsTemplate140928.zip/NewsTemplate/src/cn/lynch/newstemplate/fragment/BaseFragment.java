package cn.lynch.newstemplate.fragment;

import java.util.Timer;
import java.util.TimerTask;

import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import cn.lynch.newstemplate.activity.BaseActivity;
import cn.lynch.newstemplate.utils.AndroidUtils;

public class BaseFragment extends Fragment {

	private View mPreserveView;
	private LayoutInflater mLayoutInflater;

	@Override
	public final View onCreateView(LayoutInflater inflater,
			ViewGroup container, Bundle savedInstanceState) {
		this.mLayoutInflater = inflater;
		try {
			if (!AndroidUtils.isNetworkConnected(getActivity())) {
				// TODO 无网操作
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		if (mPreserveView != null) {
			return mPreserveView;
		} else {
			return initView(inflater, container);
		}
	}

	/**
	 * Fragment初次载入
	 * @param inflater
	 * @param container
	 * @return
	 */
	public View initView(LayoutInflater inflater, ViewGroup container) {
		return null;
	}
	
	@Override
	public void onDestroyView() {
		super.onDestroyView();
		this.mPreserveView = getView();
	}

	public LayoutInflater getLayoutInflater() {
		return mLayoutInflater;
	}

	/**
	 * 菜单、返回键响应
	 */
	public boolean onKeyDown(int keyCode, KeyEvent event) {
		if (keyCode == KeyEvent.KEYCODE_BACK) {
			exitWithDoubleClick(); // 调用双击退出函数
		}
		return false;
	}

	private static Boolean isExit = false;
	/**
	 * 双击退出函数
	 */
	private void exitWithDoubleClick() {
		Timer tExit = null;
		if (isExit == false) {
			isExit = true; // 准备退出
//			Toast.makeText(getActivity(), "再按一次退出程序", Toast.LENGTH_SHORT).show();
			((BaseActivity) getActivity()).showSafeToast("再按一次退出程序", 0);
			tExit = new Timer();
			tExit.schedule(new TimerTask() {
				@Override
				public void run() {
					isExit = false; // 取消退出
				}
			}, 2000); // 如果2秒钟内没有按下返回键，则启动定时器取消掉刚才执行的任务

		} else {
			getActivity().finish();
			System.exit(0);
		}
	}
}
