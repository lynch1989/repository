NewsTemplate
============

NewsTemplate
