package cn.lynch.newstemplate;

import android.os.Environment;

public interface ConstantValue {

	// status
	int download = 1;
	int install = 2;
	int open = 3;
	int update = 4;
	
	// pageType
	int listPage = 1;
	int detailPage = 2;
	int detailPage2 = 3;
	int updatePage = 4;
	
	// savePath
	String savePath = Environment.getExternalStorageDirectory()+ "/newstemplate";
	
	// URL
	String url = "http://115.29.137.127:8083";
}
