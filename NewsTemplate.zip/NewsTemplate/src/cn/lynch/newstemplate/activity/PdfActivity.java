package cn.lynch.newstemplate.activity;

import static java.lang.String.format;

import java.io.IOException;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;
import cn.lynch.newstemplate.R;

import com.joanzapata.pdfview.PDFView;
import com.joanzapata.pdfview.listener.OnLoadCompleteListener;
import com.joanzapata.pdfview.listener.OnPageChangeListener;
import com.lidroid.xutils.ViewUtils;
import com.lidroid.xutils.view.annotation.ContentView;
import com.lidroid.xutils.view.annotation.ViewInject;
import com.lidroid.xutils.view.annotation.event.OnClick;

@ContentView(R.layout.activity_pdf)
public class PdfActivity extends Activity implements OnPageChangeListener, OnLoadCompleteListener {

	@ViewInject(R.id.tv_pdf_name)
	private TextView tvPdfName;
	@ViewInject(R.id.pdfview)
	private PDFView pdfView;
	@ViewInject(R.id.et_feed_back_text)
	private EditText etFeedBackText;
	
	public static final String SAMPLE_FILE = "sample.pdf";
    public static final String ABOUT_FILE = "about.pdf";

    String pdfName = SAMPLE_FILE;
    Integer pageNumber = 1;
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		ViewUtils.inject(this);
		
		Intent intent = getIntent();
		pdfName = intent.getStringExtra("fileName");
		
		display(pdfName, false);
	}

	/**
	 * 判断assets目录下是否存在对应文件
	 * @param assetName
	 * @return
	 */
    @SuppressWarnings("unused")
	private boolean isAssetFileExist(String assetName) {
		try {
			return PdfActivity.this.getAssets().open(pdfName) != null;
		} catch (IOException e) {
			e.printStackTrace();
		}
		return false;
	}

    /**
     * 显示pdf
     * @param assetFileName assets目录下文件名
     * @param jumpToFirstPage 是否跳转到第一页
     */
	private void display(String assetFileName, boolean jumpToFirstPage) {
        if (jumpToFirstPage) pageNumber = 1;
        setTitle(pdfName = assetFileName);
        tvPdfName.setText(pdfName);

        pdfView.fromAsset(assetFileName)
                .defaultPage(pageNumber)
                .showMinimap(false)//放大pdf后是否显示小地图
			    .enableSwipe(true)//是否允许滑动翻页
			    .onLoad(this)
                .onPageChange(this)
                .load();
    }

	/**
	 * 按后退键时：若当前显示不是第1页，则跳转到第1页；若是第1页，则推出Activity
	 */
    @Override
    public void onBackPressed() {
		if (pageNumber != 1) {
			pdfView.jumpTo(1);
		} else {
			super.onBackPressed();
		}
    }
    
    /**
     * 加载完毕时调用
     */
	@Override
	public void loadComplete(int nbPages) {
		Toast.makeText(this, pdfName + " total pages: " + nbPages, Toast.LENGTH_SHORT).show();
	}
	
	/**
	 * 翻页时调用
	 */
	@Override
	public void onPageChanged(int page, int pageCount) {
		pageNumber = page;
        setTitle(format("%s %s / %s", pdfName, page, pageCount));
	}

	/**
	 * 发送评论按钮
	 * @param v
	 */
	@OnClick(R.id.bt_feed_back_post)
	public void postFeedBack(View v){
		String text = etFeedBackText.getText().toString().trim();
		Toast.makeText(PdfActivity.this, "get feed back: " + text, Toast.LENGTH_LONG).show();
	}
	
	/**
	 * 切换显示a.pdf
	 * @param v
	 */
	@OnClick(R.id.bt_open_a)
	public void openA(View v){
		pdfName = "a.pdf";
		display(pdfName, true);
	}
	
	/**
	 * 切换显示about.pdf
	 * @param v
	 */
	@OnClick(R.id.bt_open_about)
	public void openAbout(View v){
		pdfName = ABOUT_FILE;
		display(pdfName, true);
	}
	
	/**
	 * 切换显示sample.pdf
	 * @param v
	 */
	@OnClick(R.id.bt_open_sample)
	public void openSample(View v){
		pdfName = SAMPLE_FILE;
		display(pdfName, true);
	}
}
