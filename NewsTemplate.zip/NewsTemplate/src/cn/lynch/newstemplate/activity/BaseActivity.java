package cn.lynch.newstemplate.activity;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.Intent;
import android.content.res.ColorStateList;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.os.Process;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentActivity;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentTransaction;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.Window;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;
import cn.lynch.newstemplate.R;
import cn.lynch.newstemplate.utils.AndroidUtils;

import com.lidroid.xutils.BitmapUtils;

@SuppressLint("HandlerLeak")
public class BaseActivity extends FragmentActivity {
	
	/** 记录处于前台的Activity */
	private static BaseActivity mForegroundActivity = null;
	/** UI 线程ID */
	private long mUIThreadId;
	private LayoutInflater mInflater;
	private View mShowPageTitle;
	private Button mBtnBack;
	private TextView mPageTitle;
	private ImageView mBtnSearch;
	private RelativeLayout mMainView;
	protected BitmapUtils bitmapUtils;
	/** 当前没有网络连接 */
	protected final int MSG_NO_NETWORK = 102;
	/** 网络连接错误 */
	protected final int MSG_NETWORK_ERROR = 103;
	protected Handler mHandler = new Handler() {
		public void handleMessage(Message msg) {
			onHandleMessage(msg);
		};
	};

	@Override
	protected void onCreate(Bundle arg0) {
		super.onCreate(arg0);
		requestWindowFeature(Window.FEATURE_NO_TITLE); // 标题栏隐藏
		setContentView(R.layout.activity_base_ui);
		bitmapUtils = AndroidUtils.initBitmapUtils(this);
		initView();// 处理返回按钮和标题
	}

	@Override
	protected void onNewIntent(Intent intent) {
		mUIThreadId = android.os.Process.myTid();
		super.onNewIntent(intent);
	}

	@Override
	protected void onResume() {
		mForegroundActivity = this;
		super.onResume();
	}

	@Override
	protected void onPause() {
		mForegroundActivity = null;
		super.onPause();
	}

	/**
	 * 获取当前处于前台的activity
	 */
	public static BaseActivity getForegroundActivity() {
		return mForegroundActivity;
	}

	/**
	 * 获取UI线程ID
	 * @return UI线程ID
	 */
	public long getUIThreadId() {
		return mUIThreadId;
	}

	public Context getThemeContext() {
		return this;
	}

	public boolean post(Runnable run) {
		return mHandler.post(run);
	}

	public boolean postDelayed(Runnable run, long delay) {
		return mHandler.postDelayed(run, delay);
	}

	public void removeCallbacks(Runnable run) {
		mHandler.removeCallbacks(run);
	}

	public View inflate(int resId) {
		if (null == mInflater) {
			mInflater = LayoutInflater.from(getThemeContext());
		}
		return mInflater.inflate(resId, null);
	}

	public String[] getStringArray(int resId) {
		return getThemeContext().getResources().getStringArray(resId);
	}

	public int getDimen(int resId) {
		return getThemeContext().getResources().getDimensionPixelSize(resId);
	}

	public int getColor(int resId) {
		return getThemeContext().getResources().getColor(resId);
	}

	public ColorStateList getColorStateList(int resId) {
		return getThemeContext().getResources().getColorStateList(resId);
	}

	public Drawable getDrawable(int resId) {
		return getThemeContext().getResources().getDrawable(resId);
	}

	/**
	 * dip转换px
	 */
	public int dip2px(int dip) {
		final float scale = getResources().getDisplayMetrics().density;
		return (int) (dip * scale + 0.5f);
	}

	/**
	 * px转换dip
	 */
	public int px2dip(int px) {
		final float scale = getResources().getDisplayMetrics().density;
		return (int) (px / scale + 0.5f);
	}

	/**
	 * 对toast的简易封装。线程安全，可以在非UI线程调用
	 * @param resId
	 * @param duration
	 */
	public void showSafeToast(final int resId, final int duration) {
		if (Process.myTid() == mUIThreadId) {
			// 调用在UI线程
			Toast.makeText(getBaseContext(), resId, duration).show();
		} else {
			// 调用在非UI线程
			post(new Runnable() {
				@Override
				public void run() {
					Toast.makeText(getBaseContext(), resId, duration).show();
				}
			});
		}
	}

	/**
	 * 对toast的简易封装。线程安全，可以在非UI线程调用
	 * @param text
	 * @param duration
	 */
	public void showSafeToast(final CharSequence text, final int duration) {
		if (Process.myTid() == mUIThreadId) {
			// 调用在UI线程
			Toast.makeText(getBaseContext(), text, duration).show();
		} else {
			// 调用在非UI线程
			post(new Runnable() {
				@Override
				public void run() {
					Toast.makeText(getBaseContext(), text, duration).show();
				}
			});
		}
	}

	protected void replaceFragment(int id, Fragment fragment) {
		FragmentManager fragmentManager = getSupportFragmentManager();
		FragmentTransaction transaction = fragmentManager.beginTransaction();
		transaction.replace(id, fragment);
		transaction.commit();
	}

	private void initView() {
		mShowPageTitle = findViewById(R.id.rl_show_title);
		mBtnBack = (Button) findViewById(R.id.main_back);
		mBtnBack.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				goBack();
			}
		});
		
		mPageTitle = (TextView) findViewById(R.id.main_title_name);
		mBtnSearch = (ImageView) findViewById(R.id.main_search_btn);
		mBtnSearch.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				onSearch();
			}
		});

		mMainView = (RelativeLayout) findViewById(R.id.main_view);
	}

	protected void handlerMessage(Message msg) {

	}

	/**
	 * 搜索
	 */
	protected void onSearch() {

	}

	/**
	 * 返回
	 */
	protected void goBack() {

	}

	protected void setShowPageTitle(boolean isShow) {
		if (isShow) {
			mShowPageTitle.setVisibility(View.VISIBLE);
		} else {
			mShowPageTitle.setVisibility(View.GONE);
		}
	}

	/**
	 * 设置通用图标
	 * @param resId
	 */
	protected void setMoreBackground(int resId) {
		if (resId == -1) {
			mBtnSearch.setVisibility(View.GONE);
		} else {
			mBtnSearch.setVisibility(View.GONE);
			Bitmap bitmap = BitmapFactory.decodeResource(getResources(), resId);
			mBtnSearch.setImageBitmap(bitmap);
		}
	}

	protected void addView(View view) {
		mMainView.removeAllViews();
		RelativeLayout.LayoutParams params = new RelativeLayout.LayoutParams(
				RelativeLayout.LayoutParams.MATCH_PARENT,
				RelativeLayout.LayoutParams.MATCH_PARENT);
		mMainView.addView(view, params);
	}

	protected void addView(int viewLayout) {
		mMainView.removeAllViews();
		View view = LayoutInflater.from(this).inflate(viewLayout, null);
		RelativeLayout.LayoutParams params = new RelativeLayout.LayoutParams(
				RelativeLayout.LayoutParams.MATCH_PARENT,
				RelativeLayout.LayoutParams.MATCH_PARENT);
		mMainView.addView(view, params);
	}

	protected void setPageTitle(int resId) {
		mPageTitle.setText(resId);
	}

	protected void setPageTitle(String title) {
		mPageTitle.setText(title);
	}

	protected void setBackEnabled(boolean isEnableBack) {
		mBtnBack.setVisibility(isEnableBack ? View.VISIBLE : View.INVISIBLE);
	}

	protected void setSearchEnabled(boolean isEnableSubmit) {
		mBtnSearch.setVisibility(isEnableSubmit ? View.VISIBLE : View.INVISIBLE);
	}


	/**
	 * 由子类实现如何处理事件
	 * @param msg
	 */
	protected void onHandleMessage(Message msg) {

	}
}