package cn.lynch.newstemplate.utils;

import android.content.Context;
import android.content.Intent;
import android.content.res.ColorStateList;
import android.content.res.Resources;
import android.graphics.drawable.Drawable;
import android.os.Handler;
import android.os.Looper;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.Toast;
import cn.lynch.newstemplate.MyApplication;
import cn.lynch.newstemplate.activity.BaseActivity;


public class UIUtils {

	public static Context getContext() {
		return MyApplication.getApplication();
	}

	public static Thread getMainThread() {
		return MyApplication.getMainThread();
	}

	public static long getMainThreadId() {
		return MyApplication.getMainThreadId();
	}

	/**
	 * dip转换px
	 * @param dip
	 * @return
	 */
	public static int dip2px(int dip) {
		final float scale = getContext().getResources().getDisplayMetrics().density;
		return (int) (dip * scale + 0.5f);
	}

	/**
	 * px转换dip
	 * @param px
	 * @return
	 */
	public static int px2dip(int px) {
		final float scale = getContext().getResources().getDisplayMetrics().density;
		return (int) (px / scale + 0.5f);
	}

	/**
	 * 获取主线程的handler
	 * @return
	 */
	public static Handler getHandler() {
		// 获得主线程的looper
		Looper mainLooper = MyApplication.getMainThreadLooper();
		// 获取主线程的handler
		Handler handler = new Handler(mainLooper);
		return handler;
	}

	/**
	 * 延时在主线程执行runnable
	 * @param runnable
	 * @param delayMillis
	 * @return
	 */
	public static boolean postDelayed(Runnable runnable, long delayMillis) {
		return getHandler().postDelayed(runnable, delayMillis);
	}

	/**
	 * 在主线程执行runnable
	 * @param runnable
	 * @return
	 */
	public static boolean post(Runnable runnable) {
		return getHandler().post(runnable);
	}

	/**
	 * 从主线程looper里面移除runnable
	 * @param runnable
	 */
	public static void removeCallbacks(Runnable runnable) {
		getHandler().removeCallbacks(runnable);
	}

	public static View inflate(int resId) {
		return LayoutInflater.from(getContext()).inflate(resId, null);
	}

	/**
	 * 获取资源
	 * @return
	 */
	public static Resources getResources() {
		return getContext().getResources();
	}

	/**
	 * 获取文字
	 * @param resId
	 * @return
	 */
	public static String getString(int resId) {
		return getResources().getString(resId);
	}

	/**
	 * 获取文字数组
	 * @param resId
	 * @return
	 */
	public static String[] getStringArray(int resId) {
		return getResources().getStringArray(resId);
	}

	/**
	 * 获取dimen
	 * @param resId
	 * @return
	 */
	public static int getDimens(int resId) {
		return getResources().getDimensionPixelSize(resId);
	}

	/**
	 * 获取drawable
	 * @param resId
	 * @return
	 */
	public static Drawable getDrawable(int resId) {
		return getResources().getDrawable(resId);
	}

	/**
	 * 获取颜色
	 * @param resId
	 * @return
	 */
	public static int getColor(int resId) {
		return getResources().getColor(resId);
	}

	/**
	 * 获取颜色选择器
	 * @param resId
	 * @return
	 */
	public static ColorStateList getColorStateList(int resId) {
		return getResources().getColorStateList(resId);
	}

	public static boolean isRunInMainThread() {
		return android.os.Process.myTid() == getMainThreadId();
	}

	public static void runInMainThread(Runnable runnable) {
		if (isRunInMainThread()) {
			runnable.run();
		} else {
			post(runnable);
		}
	}

	public static void startActivity(Intent intent) {
		BaseActivity activity = BaseActivity.getForegroundActivity();
		if (activity != null) {
			activity.startActivity(intent);
		} else {
			intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
			getContext().startActivity(intent);
		}
	}
	
	/**
	 * 对Toast的简易封装。线程安全，可以在非UI线程调用
	 * 显示短时间Toast
	 * @param resId
	 */
	public static void showShortSafeToast(final int resId) {
		showShortSafeToast(getString(resId));
	}
	
	/**
	 * 对Toast的简易封装。线程安全，可以在非UI线程调用
	 * 显示短时间Toast
	 * @param str
	 */
	public static void showShortSafeToast(final String str) {
		if (isRunInMainThread()) {
			showShortToast(str);
		} else {
			post(new Runnable() {
				@Override
				public void run() {
					showShortToast(str);
				}
			});
		}
	}

	/**
	 * 对Toast的简易封装。线程安全，可以在非UI线程调用
	 * 显示长时间Toast
	 * @param resId
	 */
	public static void showLongSafeToast(final int resId) {
		showLongSafeToast(getString(resId));
	}

	/**
	 * 对Toast的简易封装。线程安全，可以在非UI线程调用
	 * 显示长时间Toast
	 * @param str
	 */
	public static void showLongSafeToast(final String str) {
		if (isRunInMainThread()) {
			showLongToast(str);
		} else {
			post(new Runnable() {
				@Override
				public void run() {
					showLongToast(str);
				}
			});
		}
	}
	
	private static void showShortToast(String str) {
		BaseActivity frontActivity = BaseActivity.getForegroundActivity();
		if (frontActivity != null) {
			Toast.makeText(frontActivity, str, Toast.LENGTH_SHORT).show();
		}
	}

	private static void showLongToast(String str) {
		BaseActivity frontActivity = BaseActivity.getForegroundActivity();
		if (frontActivity != null) {
			Toast.makeText(frontActivity, str, Toast.LENGTH_LONG).show();
		}
	}
}
