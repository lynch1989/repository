package cn.lynch.newstemplate.utils;

import java.io.IOException;
import java.io.InputStream;
import java.security.MessageDigest;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import android.annotation.SuppressLint;
import android.app.ActivityManager;
import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.content.pm.PackageManager.NameNotFoundException;
import android.content.res.AssetManager;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ListAdapter;
import android.widget.ListView;
import cn.lynch.newstemplate.bean.Apk;

import com.lidroid.xutils.BitmapUtils;
import com.lidroid.xutils.bitmap.BitmapCommonUtils;
import com.lidroid.xutils.bitmap.BitmapDisplayConfig;

/**
 * Android常用小工具
 */
public class AndroidUtils {
	
	// ----------------------dp、px、sp的转换-----------------------------
	/**
	 * 将px值转换为dip或dp值，保证尺寸大小不变
	 */
	public static int px2dp(Context context, float pxValue) {
		final float scale = context.getResources().getDisplayMetrics().density;
		return (int) (pxValue / scale + 0.5f);
	}

	/**
	 * 将dip或dp值转换为px值，保证尺寸大小不变
	 */
	public static int dp2px(Context context, float dipValue) {
		final float scale = context.getResources().getDisplayMetrics().density;
		return (int) (dipValue * scale + 0.5f);
	}

	/**
	 * 将px值转换为sp值，保证文字大小不变
	 */
	public static int px2sp(Context context, float pxValue) {
		final float fontScale = context.getResources().getDisplayMetrics().scaledDensity;
		return (int) (pxValue / fontScale + 0.5f);
	}

	/**
	 * 将sp值转换为px值，保证文字大小不变
	 */
	public static int sp2px(Context context, float spValue) {
		final float fontScale = context.getResources().getDisplayMetrics().scaledDensity;
		return (int) (spValue * fontScale + 0.5f);
	}

	/**
	 * 获取XUtils的BigtmapUtils对象
	 */
	public static BitmapUtils initBitmapUtils(Context context) {
		BitmapUtils bitmapUtils = new BitmapUtils(context);
		// 压缩图片
		BitmapDisplayConfig bigPicDisplayConfig = new BitmapDisplayConfig();
		bigPicDisplayConfig.setBitmapConfig(Bitmap.Config.RGB_565);
		bigPicDisplayConfig.setBitmapMaxSize(BitmapCommonUtils
				.getScreenSize(context));
		bitmapUtils.configDefaultDisplayConfig(bigPicDisplayConfig);
		return bitmapUtils;
	}

	/**
	 * 将versionName转换为Long类型
	 */
	public static long versionNameToLong(String versionName) {
		long versionL = 0;
		if (TextUtils.isEmpty(versionName)) {
			return 0;
		}
		String[] split = versionName.split("\\D");
		// String[] split = split1[0].split("\\.");
		// String[] split = versionName.split("\\.");
		try {
			String[] split2 = { "0", "0", "0", "0", "0" };
			System.arraycopy(split, 0, split2, 0, split.length);
			for (int i = 0; i < split2.length; i++) {
				int parseInt = Integer.parseInt(split2[i]);
				int temp = split2.length - 1 - i;
				if (temp != 0) {
					versionL += parseInt << (8 * temp);
				} else {
					versionL += parseInt;
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
			LogUtils.e(e.toString());
		}
		return versionL;
	}

	/**
	 * 获取所有已安装的应用的版本Map集合
	 */
	public static Map<String, Long> getAllInstalledAppVersion(PackageManager pm) {
		Map<String, Long> result = null;
		// 得到包管理器
		// PackageManager pm = context.getPackageManager();
		try {
			result = new HashMap<String, Long>();
			List<PackageInfo> packInfos = pm
					.getInstalledPackages(PackageManager.GET_UNINSTALLED_PACKAGES);
			for (PackageInfo info : packInfos) {
				// 应用程序的标志，可以是任意标志的组合
				int flags = info.applicationInfo.flags;// 应用程序交的答题卡

				if ((flags & ApplicationInfo.FLAG_SYSTEM) == 0) {
					// 某一个APK的信息
					String packageName = info.packageName;
					if (packageName.equals("com.qiyi.video")) {
					}
					// int versionCode = info.versionCode;
					String versionName = info.versionName;
					long versionL = AndroidUtils.versionNameToLong(versionName);
					result.put(packageName, versionL);
				}
			}
		} catch (Exception e) {
			return result;
		}
		return result;
	}
	
	/**
	 * 获取所有已安装的应用的详情List集合
	 */
	public static List<Apk> getAllInstalledAppList(PackageManager pm) {
		List<Apk> result = null;
		// 得到包管理器
		// PackageManager pm = context.getPackageManager();
		try {
			result = new ArrayList<Apk>();
			List<PackageInfo> packInfos = pm
					.getInstalledPackages(PackageManager.GET_UNINSTALLED_PACKAGES);
			for (PackageInfo info : packInfos) {
				// 应用程序的标志，可以是任意标志的组合
				int flags = info.applicationInfo.flags;// 应用程序交的答题卡

				if ((flags & ApplicationInfo.FLAG_SYSTEM) == 0) {
					// 如果不是系统应用，将其加到List中。
					Apk apk = new Apk();
					apk.setPackageName(info.packageName);
					String packageName = info.packageName;
					if (packageName.equals("com.qiyi.video")) {
					}
					int versionCode=info.versionCode;
					apk.setLocalVersion(versionCode+"");
					result.add(apk);
				}
			}
		} catch (Exception e) {
			return result;
		}
		return result;
	}

	/**
	 * 根据包名获取VersionCode，如果没有安装，返回-1
	 */
	public static int getVersionCode(Context context, String packageName) {
		if (packageName == null || "".equals(packageName))
			return -1;
		try {
			PackageInfo packageInfo = context.getPackageManager()
					.getPackageInfo(packageName,
							PackageManager.GET_UNINSTALLED_PACKAGES);
			return packageInfo.versionCode;
		} catch (NameNotFoundException e) {
			return -1;
		}
	}

	/**
	 * 检查某个应用是否安装 如果已安装则返回versionCode，如果未安装则返回-1
	 */
	public static int checkAPP1(Context context, String packageName) {
		if (packageName == null || "".equals(packageName))
			return -1;
		try {
			PackageInfo packageInfo = context.getPackageManager()
					.getPackageInfo(packageName,
							PackageManager.GET_UNINSTALLED_PACKAGES);
			return packageInfo.versionCode;
		} catch (NameNotFoundException e) {
			return -1;
		}
	}

	/**
	 * 检测是否联网
	 */
	public static boolean isNetworkConnected(Context context) {
		if (context != null) {
			try {
				ConnectivityManager mConnectivityManager = (ConnectivityManager) context
						.getSystemService(Context.CONNECTIVITY_SERVICE);
				NetworkInfo mNetworkInfo = mConnectivityManager
						.getActiveNetworkInfo();
				if (mNetworkInfo != null) {
					return mNetworkInfo.isAvailable();
				}
			} catch (Exception e) {
				e.printStackTrace();
				LogUtils.e(e.toString());
			}
		}
		return false;
	}
	
	/**
	 * 检查传入的Service是否在运行
	 */
    @SuppressWarnings("rawtypes")
	public static boolean isServiceRunning(Context context, Class serviceClass) {
        boolean isRunning = false;

        ActivityManager activityManager =
                (ActivityManager) context.getSystemService(Context.ACTIVITY_SERVICE);
        List<ActivityManager.RunningServiceInfo> serviceList
                = activityManager.getRunningServices(Integer.MAX_VALUE);

        if (serviceList == null || serviceList.size() == 0) {
            return false;
        }

        for (int i = 0; i < serviceList.size(); i++) {
            if (serviceList.get(i).service.getClassName().equals(serviceClass.getName())) {
                isRunning = true;
                break;
            }
        }
        return isRunning;
    }
    
    /**
	 * 获取AndroidManifest.xml中name为metaKey的meta-data对应的value
	 * @param context
	 * @param metaKey
	 * @return
	 */
	public static String getMetaValue(Context context, String metaKey) {
		Bundle metaData = null;
		String metaValue = null;
		if (context == null || metaKey == null) {
			return null;
		}
		try {
			ApplicationInfo ai = context.getPackageManager()
					.getApplicationInfo(context.getPackageName(),
							PackageManager.GET_META_DATA);
			if (null != ai) {
				metaData = ai.metaData;
			}
			if (null != metaData) {
				metaValue = metaData.getString(metaKey);
			}
		} catch (NameNotFoundException e) {
			LogUtils.e(e.toString());
		}
		return metaValue;
	}
	
	/**
	 * 根据ListView的子项条目设置ListView的高
	 * @param listView
	 */
	public static void setListViewHeightBasedOnChildren(ListView listView) {
		// 获取ListView对应的Adapter
		ListAdapter listAdapter = listView.getAdapter();
		if (listAdapter == null) {
			return;
		}
		int totalHeight = 0;
		for (int i = 0; i < listAdapter.getCount(); i++) { // listAdapter.getCount()返回数据项的数目
			View listItem = listAdapter.getView(i, null, listView);
			listItem.measure(0, 0); // 计算子项View 的宽高
			totalHeight += listItem.getMeasuredHeight(); // 统计所有子项的总高度
		}
		ViewGroup.LayoutParams params = listView.getLayoutParams();
		params.height = totalHeight
				+ (listView.getDividerHeight() * (listAdapter.getCount() - 1));
		// listView.getDividerHeight()获取子项间分隔符占用的高度
		// params.height最后得到整个ListView完整显示需要的高度
		listView.setLayoutParams(params);
	}
	
	/**
	 * 获取现在时间
	 * @return 返回短时间字符串格式yyyy-MM-dd HH:mm:ss
	 */
	@SuppressLint("SimpleDateFormat")
	public static String getStringDate() {
		SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		String dateString = formatter.format(new Date());
		return dateString;
	}
	
	public static Bitmap getImageFromAssetsFile(Context context, String fileName) {
		Bitmap image = null;
		AssetManager am = context.getAssets();
		try {
			InputStream is = am.open(fileName);
			image = BitmapFactory.decodeStream(is);
			is.close();
		} catch (IOException e) {
			e.printStackTrace();
			LogUtils.e(e.toString());
		}
		return image;
	}
	
	/**
	 * 将指定byte数组转换成16进制字符串
	 * @param b
	 * @return
	 */
	public static String byteToHexString(byte[] b) {
		StringBuffer hexString = new StringBuffer();
		for (int i = 0; i < b.length; i++) {
			String hex = Integer.toHexString(b[i] & 0xFF);
			if (hex.length() == 1) {
				hex = '0' + hex;
			}
			hexString.append(hex.toUpperCase());
		}
		return hexString.toString();
	}
	
	public static void showInfoDialog(Context context, String message) {
		showInfoDialog(context, message, "提示", "确定", null);
	}

	public static void showInfoDialog(Context context, String message,
			String titleStr, String positiveStr,
			DialogInterface.OnClickListener onClickListener) {
		AlertDialog.Builder localBuilder = new AlertDialog.Builder(context);
		localBuilder.setTitle(titleStr);
		localBuilder.setMessage(message);
		if (onClickListener == null)
			onClickListener = new DialogInterface.OnClickListener() {
				public void onClick(DialogInterface dialog, int which) {

				}
			};
		localBuilder.setPositiveButton(positiveStr, onClickListener);
		localBuilder.show();
	}
	
	public static String md5(String paramString) {
		String returnStr;
		try {
			MessageDigest localMessageDigest = MessageDigest.getInstance("MD5");
			localMessageDigest.update(paramString.getBytes());
			returnStr = byteToHexString(localMessageDigest.digest());
			return returnStr;
		} catch (Exception e) {
			return paramString;
		}
	}
}
