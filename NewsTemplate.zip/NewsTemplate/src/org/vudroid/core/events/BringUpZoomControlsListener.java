package org.vudroid.core.events;

public interface BringUpZoomControlsListener
{
    public void toggleZoomControls();
}
